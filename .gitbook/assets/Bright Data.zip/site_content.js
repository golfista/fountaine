/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!*************************************!*\
  !*** ./src/content/site_content.js ***!
  \*************************************/
// LICENSE_CODE ZON


/*jslint browser:true, es6:true, react:true*/
(function (data) {
  function lum_updates(d) {
    if (d.navigator) {
      var _loop = function _loop(prop) {
        if (!d.navigator.hasOwnProperty(prop)) return "continue";
        navigator.__defineGetter__(prop, function () {
          if (d.navigator[prop] == '__UNDEFINED__') return undefined;
          return d.navigator[prop];
        });
      };
      for (var prop in d.navigator) {
        var _ret = _loop(prop);
        if (_ret === "continue") continue;
      }
    }
    if (d.window) {
      for (var _prop in d.window) {
        if (!d.window.hasOwnProperty(_prop)) continue;
        if (d.window[_prop] == '__UNDEFINED__') window[_prop] = undefined;else window[_prop] = d.window[_prop];
      }
    }
    if (d.patch_webgl && window.WebGLRenderingContext) patch_webgl(window.WebGLRenderingContext);
    if (d.patch_webgl && window.WebGLRenderingContext) patch_webgl(window.WebGL2RenderingContext);
    function patch_webgl(obj) {
      if (!obj) return;
      var unmasked_renderer_webgl = 0x9246;
      var unmasked_vendor_webgl = 0x9245;
      var get_param_bkp = obj.prototype.getParameter;
      obj.prototype.getParameter = function (p) {
        var is_apple = navigator.vendor.match(/Apple/);
        if (p == unmasked_vendor_webgl) return is_apple ? 'Apple Inc.' : 'WebKit';
        if (p == unmasked_renderer_webgl) return is_apple ? 'Apple A10 GPU' : 'WebKit WebGL';
        if (p == obj.VERSION) return 'WebGL 1.0 OpenGL ES 2.0 Metal - 50.8';
        return get_param_bkp.call(this, p);
      };
    }
  }
  lum_updates(data);
})(document.currentScript.dataset);
/******/ })()
;