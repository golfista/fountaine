/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./util/array.js":
/*!***********************!*\
  !*** ./util/array.js ***!
  \***********************/
/***/ ((module, exports) => {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
var module;
// LICENSE_CODE ZON ISC
'use strict'; /*jslint node:true, browser:true*/
(function(){

var is_node_ff = typeof module=='object' && module.exports;
if (!is_node_ff)
    ;
else
    ;
!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function(){
var E = {};

var proto_slice = Array.prototype.slice;
E.copy = function(a){
    switch (a.length)
    {
    case 0: return [];
    case 1: return [a[0]];
    case 2: return [a[0], a[1]];
    case 3: return [a[0], a[1], a[2]];
    case 4: return [a[0], a[1], a[2], a[3]];
    case 5: return [a[0], a[1], a[2], a[3], a[4]];
    default: return proto_slice.call(a);
    }
};

E.push = function(a){
    for (var i=1; i<arguments.length; i++)
    {
        var arg = arguments[i];
        if (Array.isArray(arg))
            a.push.apply(a, arg);
        else
            a.push(arg);
    }
    return a.length;
};
E.unshift = function(a){
    for (var i=arguments.length-1; i>0; i--)
    {
        var arg = arguments[i];
        if (Array.isArray(arg))
            a.unshift.apply(a, arg);
        else
            a.unshift(arg);
    }
    return a.length;
};

E.slice = function(args, from, to){
    return Array.prototype.slice.call(args, from, to); };

E.compact = function(a){ return E.compact_self(a.slice()); };
E.compact_self = function(a){
    var i, j, n = a.length;
    for (i=0; i<n && a[i]; i++);
    if (i==n)
        return a;
    for (j=i; i<n; i++)
    {
        if (!a[i])
            continue;
        a[j++] = a[i];
    }
    a.length = j;
    return a;
};

// same as _.flatten(a, true)
E.flatten_shallow = function(a){ return Array.prototype.concat.apply([], a); };
E.flatten = function(a){
    var _a = [], i;
    for (i=0; i<a.length; i++)
    {
        if (Array.isArray(a[i]))
            Array.prototype.push.apply(_a, E.flatten(a[i]));
        else
            _a.push(a[i]);
    }
    return _a;
};
E.flat_map = function(a, cb){
    if (a.flatMap)
        return a.flatMap(cb);
    return Array.prototype.concat.apply([], a.map(cb));
};

E.unique = function(a){
    var _a = [];
    for (var i=0; i<a.length; i++)
    {
        if (!_a.includes(a[i]))
            _a.push(a[i]);
    }
    return _a;
};
E.to_nl = function(a, sep){
    if (!a || !a.length)
        return '';
    if (sep===undefined)
        sep = '\n';
    return a.join(sep)+sep;
};
E.sed = function(a, regex, replace){
    var _a = new Array(a.length), i;
    for (i=0; i<a.length; i++)
        _a[i] = a[i].replace(regex, replace);
    return _a;
};
E.grep = function(a, regex, replace){
    var _a = [], i;
    for (i=0; i<a.length; i++)
    {
        // don't use regex.test() since with //g sticky tag it does not reset
        if (a[i].search(regex)<0)
            continue;
        if (replace!==undefined)
            _a.push(a[i].replace(regex, replace));
        else
            _a.push(a[i]);
    }
    return _a;
};

E.rm_elm = function(a, elm){
    var i = a.indexOf(elm);
    if (i<0)
        return;
    a.splice(i, 1);
    return elm;
};

E.rm_elm_tail = function(a, elm){
    var i = a.length-1;
    if (elm===a[i]) // fast-path
    {
        a.pop();
        return elm;
    }
    if ((i = a.lastIndexOf(elm, i-1))<0)
        return;
    a.splice(i, 1);
    return elm;
};

E.add_elm = function(a, elm){
    if (a.includes(elm))
        return;
    a.push(elm);
    return elm;
};

E.split_every = function(a, n){
    var ret = [];
    for (var i=0; i<a.length; i+=n)
        ret.push(a.slice(i, i+n));
    return ret;
};

E.split_at = function(a, delim){
    var ret = [];
    delim = delim||'';
    for (var i=0; i<a.length; i++)
    {
        var chunk = [];
        for (; i<a.length && a[i]!=delim; i++)
            chunk.push(a[i]);
        if (chunk.length)
            ret.push(chunk);
    }
    return ret;
};

E.rotate = function(a, n){
    if (a && a.length>1 && (n = n%a.length))
        E.unshift(a, a.splice(n));
    return a;
};

E.move = function(a, from, to, n){
    return Array.prototype.splice.apply(a, [to, n]
        .concat(a.slice(from, from+n)));
};

E.to_array = function(v){ return Array.isArray(v) ? v : v==null ? [] : [v]; };

E.enumerate = function(arr){
    return Array.from(arr).map(function(e, i){ return [i, e]; });
};

E.range = function(length){
    return Array.from({length: length}).map(function(_, i){ return i; });
};

var proto = {};
proto.sed = function(regex, replace){
    return E.sed(this, regex, replace); };
proto.grep = function(regex, replace){
    return E.grep(this, regex, replace); };
proto.to_nl = function(sep){ return E.to_nl(this, sep); };
proto.push_a = function(){
    return E.push.apply(null, [this].concat(Array.from(arguments))); };
proto.unshift_a = function(){
    return E.unshift.apply(null, [this].concat(Array.from(arguments))); };
var installed;
E.prototype_install = function(){
    if (installed)
        return;
    installed = true;
    for (var i in proto)
    {
        Object.defineProperty(Array.prototype, i,
            {value: proto[i], configurable: true, enumerable: false,
            writable: true});
    }
};
E.prototype_uninstall = function(){
    if (!installed)
        return;
    installed = false;
    // XXX sergey: store orig proto, then load it back
    for (var i in proto)
        delete Array.prototype[i];
};
return E; }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)); }());


/***/ }),

/***/ "./util/date.js":
/*!**********************!*\
  !*** ./util/date.js ***!
  \**********************/
/***/ ((module, exports) => {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
var module;
// LICENSE_CODE ZON ISC
'use strict'; /*jslint node:true, browser:true*/
(function(){

var is_node = typeof module=='object' && module.exports && module.children;
var is_node_ff = typeof module=='object' && module.exports;
if (!is_node_ff)
    ;
else
    ;
!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function(){
var E = date_get;

E.sec = {
    NANO: 1e-9,
    MICRO: 1e-6,
    MS: 1e-3,
    SEC: 1,
    MIN: 60,
    HOUR: 60*60,
    DAY: 24*60*60,
    WEEK: 7*24*60*60,
    MONTH: 30*24*60*60,
    YEAR: 365*24*60*60,
};
E.ms = {};
for (var key in E.sec)
    E.ms[key] = E.sec[key]*1000;
var ms = E.ms;

var pads = ['', '0', '00', '000'];
function pad(num, size){
    var s = num.toString();
    return pads[size-s.length]+s;
}

E.ms_to_dur = function(_ms){
    var s = '', sec = Math.floor(_ms/1000);
    if (sec<0)
    {
        s += '-';
        sec = -sec;
    }
    var days = Math.floor(sec/(60*60*24));
    sec -= days*60*60*24;
    var hours = Math.floor(sec/(60*60));
    sec -= hours*60*60;
    var mins = Math.floor(sec/60);
    sec -= mins*60;
    if (days)
        s += days + ' ' + (days>1 ? 'Days' : 'Day') + ' ';
    return s+pad(hours, 2)+':'+pad(mins, 2)+':'+pad(sec, 2);
};

E.round_dur = function(dur, precision){
    return !precision ? Math.round(dur) : precision*Math.round(dur/precision);
};

E.dur_to_str = function(dur, opt){
    opt = opt||{};
    var parts = [];
    dur = E.round_dur(+dur, opt.precision);
    function chop(period, name){
        if (dur<period)
            return;
        var number = Math.floor(dur/period);
        parts.push(number+name);
        dur -= number*period;
    }
    chop(ms.YEAR, 'y');
    chop(ms.MONTH, 'mo');
    if (opt.week)
        chop(ms.WEEK, 'w');
    chop(ms.DAY, 'd');
    chop(ms.HOUR, 'h');
    chop(ms.MIN, 'min');
    chop(ms.SEC, 's');
    if (dur)
        parts.push(dur+'ms');
    if (!parts.length)
        return '0s';
    return parts.slice(0, opt.units||parts.length).join(opt.sep||'');
};

// google sheets duration format
E.dur_to_gs_str = function(dur, opt){
    opt = opt||{};
    var parts = [];
    dur = E.round_dur(+dur, opt.precision);
    function chop(period){
        var number = Math.floor(dur/period);
        parts.push(number);
        dur -= number*period;
    }
    chop(ms.HOUR);
    chop(ms.MIN);
    var res = [''+parts[0]]
        .concat(parts.slice(1)
            .map(function(p){ return (''+p).padStart(2, '0'); }))
        .concat((dur/ms.SEC)
            .toLocaleString('en-US', {minimumIntegerDigits: 2}));
    return res.join(':');
};

E.monotonic = undefined;
E.init = function(){
    var adjust, last;
    if (typeof window=='object' && window.performance
        && window.performance.now)
    {
        // 10% slower than Date.now, but always monotonic
        adjust = Date.now()-window.performance.now();
        E.monotonic = function(){ return window.performance.now()+adjust; };
    }
    else if (is_node && !global.mocha_running)
    {
        var now_fn = function(){
            var data = process.hrtime();
            var seconds = data[0], nanos = data[1];
            return Math.floor(seconds * E.ms.SEC + nanos * E.ms.NANO);
        };
        adjust = Date.now()-now_fn();
        E.monotonic = function(){ return now_fn()+adjust; };
    }
    else
    {
        last = adjust = 0;
        E.monotonic = function(){
            var now = Date.now()+adjust;
            if (now>=last)
                return last = now;
            adjust += last-now;
            return last;
        };
    }
};
E.init();

E.str_to_dur = function(str, opt){
    opt = opt||{};
    var month = 'mo|mon|months?';
    if (opt.short_month)
        month +='|m';
    var m = str.replace(/ /g, '').match(new RegExp('^(([0-9]+)y(ears?)?)?'
        +'(([0-9]+)('+month+'))?(([0-9]+)w(eeks?)?)?(([0-9]+)d(ays?)?)?'
        +'(([0-9]+)h(ours?)?)?(([0-9]+)(min|minutes?))?'
        +'(([0-9]+)s(ec|econds?)?)?(([0-9]+)ms(ec)?)?$', 'i'));
    if (!m)
        return;
    return ms.YEAR*(+m[2]||0)+ms.MONTH*(+m[5]||0)+ms.WEEK*(+m[8]||0)
    +ms.DAY*(+m[11]||0)+ms.HOUR*(+m[14]||0)+ms.MIN*(+m[17]||0)
    +ms.SEC*(+m[20]||0)+(+m[23]||0);
};

E.months_long = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'];
E.months_short = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',
    'Sep', 'Oct', 'Nov', 'Dec'];
var months_short_lc = E.months_short.map(function(m){
    return m.toLowerCase(); });
E.days_long = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday',
    'Friday', 'Saturday'];
E.days_short = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
var days_short_lc = E.days_short.map(function(d){ return d.toLowerCase(); });
var days_long_lc = E.days_long.map(function(d){ return d.toLowerCase(); });
E.locale = {months_long: E.months_long, months_short: E.months_short,
    days_long: E.days_long, days_short: E.days_short, AM: 'AM', PM: 'PM'};
E.get = date_get;
function date_get(d, _new){
    var y, mon, day, H, M, S, _ms;
    if (d==null)
        return new Date();
    if (d instanceof Date)
        return _new ? new Date(d) : d;
    if (typeof d=='string')
    {
        var m;
        d = d.trim();
        // check for ISO/SQL/JDate date
        if (m = /^((\d\d\d\d)-(\d\d)-(\d\d)|(\d\d?)-([A-Za-z]{3})-(\d\d(\d\d)?))\s*([\sT](\d\d):(\d\d)(:(\d\d)(\.(\d\d\d))?)?Z?)?$/
            .exec(d))
        {
            H = +m[10]||0; M = +m[11]||0; S = +m[13]||0; _ms = +m[15]||0;
            if (m[2]) // SQL or ISO date
            {
                y = +m[2]; mon = +m[3]; day = +m[4];
                if (!y && !mon && !day && !H && !M && !S && !_ms)
                    return new Date(NaN);
                return new Date(Date.UTC(y, mon-1, day, H, M, S, _ms));
            }
            if (m[5]) // jdate
            {
                y = +m[7];
                mon = months_short_lc.indexOf(m[6].toLowerCase())+1;
                day = +m[5];
                if (m[7].length==2)
                {
                    y = +y;
                    y += y>=70 ? 1900 : 2000;
                }
                return new Date(Date.UTC(y, mon-1, day, H, M, S, _ms));
            }
            // cannot reach here
        }
        // check for string timestamp
        if (/^\d+$/.test(d))
            return new Date(+d);
        // else might be parsed as non UTC!
        return new Date(d);
    }
    if (typeof d=='number')
        return new Date(d);
    throw new TypeError('invalid date '+d);
}

E.is_valid = function(d){ return d instanceof Date && !isNaN(d); };

E.to_sql_ms = function(d){
    d = E.get(d);
    if (isNaN(d))
        return '0000-00-00 00:00:00.000';
    return d.getUTCFullYear()+'-'+pad(d.getUTCMonth()+1, 2)
    +'-'+pad(d.getUTCDate(), 2)
    +' '+pad(d.getUTCHours(), 2)+':'+pad(d.getUTCMinutes(), 2)
    +':'+pad(d.getUTCSeconds(), 2)
    +'.'+pad(d.getUTCMilliseconds(), 3);
};
E.to_sql_sec = function(d){ return E.to_sql_ms(d).slice(0, -4); };
E.to_sql = function(d){
    return E.to_sql_ms(d).replace(/( 00:00:00)?....$/, ''); };
E.from_sql = E.get;

E.to_month_short = function(d){
    d = E.get(d);
    return E.months_short[d.getUTCMonth()];
};
E.to_month_long = function(d){
    d = E.get(d);
    return E.months_long[d.getUTCMonth()];
};
// timestamp format (used by tickets, etc). dates before 2000 not supported
E.to_jdate = function(d){
    d = E.get(d);
    return (pad(d.getUTCDate(), 2)+'-'+E.months_short[d.getUTCMonth()]
        +'-'+pad(d.getUTCFullYear()%100, 2)+' '+pad(d.getUTCHours(), 2)+
        ':'+pad(d.getUTCMinutes(), 2)+':'+pad(d.getUTCSeconds(), 2))
    .replace(/( 00:00)?:00$/, '');
};
// used in log file names
E.to_log_file = function(d){
    d = E.get(d);
    return d.getUTCFullYear()+pad(d.getUTCMonth()+1, 2)+pad(d.getUTCDate(), 2)
    +'_'+pad(d.getUTCHours(), 2)+pad(d.getUTCMinutes(), 2)
    +pad(d.getUTCSeconds(), 2);
};
E.from_log_file = function(d){
    var m = d.match(/^(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})(\d{2})$/);
    if (!m)
        return;
    return new Date(Date.UTC(m[1], m[2]-1, m[3], m[4], m[5], m[6]));
};
// zerr compatible timestamp format
E.to_log_ms = function(d){ return E.to_sql_ms(d).replace(/-/g, '.'); };
E.from_rcs = function(d){
    var m = d.match(/^(\d{4})\.(\d{2})\.(\d{2})\.(\d{2})\.(\d{2})\.(\d{2})$/);
    if (!m)
        return;
    return new Date(Date.UTC(m[1], m[2]-1, m[3], m[4], m[5], m[6]));
};
E.to_rcs = function(d){ return E.to_sql_sec(d).replace(/[-: ]/g, '.'); };

E.align = function(d, align){
    d = E.get(d, 1);
    switch (align.toUpperCase())
    {
    case 'MS': break;
    case 'SEC': d.setUTCMilliseconds(0); break;
    case 'MIN': d.setUTCSeconds(0, 0); break;
    case 'HOUR': d.setUTCMinutes(0, 0, 0); break;
    case 'DAY': d.setUTCHours(0, 0, 0, 0); break;
    case 'WEEK':
        d.setUTCDate(d.getUTCDate()-d.getUTCDay());
        d.setUTCHours(0, 0, 0, 0);
        break;
    case 'MONTH': d.setUTCDate(1); d.setUTCHours(0, 0, 0, 0); break;
    case 'YEAR': d.setUTCMonth(0, 1); d.setUTCHours(0, 0, 0, 0); break;
    default: throw new Error('invalid align '+align);
    }
    return d;
};

E.align_up = function(d, align){
    d = E.get(d, 1);
    var mult;
    switch (align.toUpperCase())
    {
    case 'MS': break;
    case 'SEC': mult = ms.SEC; break;
    case 'MIN': mult = ms.MIN; break;
    case 'HOUR': mult = ms.HOUR; break;
    case 'DAY': mult = ms.DAY; break;
    default: throw new Error('invalid align '+align);
    }
    return new Date(Math.ceil(d/mult)*mult);
};

E.today = function(now){
    return E.align(now, 'DAY');
};

E.nth_of_month = function(now, n){
    if (n===undefined)
    {
        n = now;
        now = date_get();
    }
    var res = E.align(now, 'MONTH');
    var last_day = E.last_day_of_month(res);
    if (n<0)
        res = E.add(res, {d: last_day+n});
    else if (n>1)
        res = E.add(res, {d: n-1});
    return res;
};

E.last_day_of_month = function(month, year){
    if (year===undefined && !(Number.isFinite(month)&&month>=1&&month<=12)
        && E.is_date_like(month))
    {
        var d = date_get(month);
        month = d.getUTCMonth()+1;
        year = d.getUTCFullYear();
    }
    var ts = Date.UTC(year||2001, month, 0); // default to non-leap year
    return new Date(ts).getUTCDate();
};

E.add = function(d, dur){
    d = E.get(d, 1);
    dur = normalize_dur(dur);
    // manual handling, because of '31-Jan + 1 month'
    // we are doing same as: momentjs, C# DateTime, Excel EDATE, R Lubridate
    // see: https://lubridate.tidyverse.org/reference/mplus.html
    if (dur.year || dur.month)
    {
        var year = d.getUTCFullYear() + (dur.year||0);
        var month = d.getUTCMonth() + (dur.month||0);
        var day = d.getUTCDate();
        while (month<0)
        {
            year--;
            month += 12;
        }
        while (month>=12)
        {
            year++;
            month -= 12;
        }
        day = Math.min(day, E.last_day_of_month(month+1, year));
        d.setUTCFullYear(year, month, day);
    }
    ['day', 'hour', 'min', 'sec', 'ms'].forEach(function(k){
        if (dur[k])
            d.setTime(+d+dur[k]*ms[k.toUpperCase()]);
    });
    return d;
};

function normalize_dur(dur){
    var aliases = {
        years: 'year', months: 'month', days: 'day',
        hours: 'hour', minutes: 'min', seconds: 'sec',
        minute: 'min', mins: 'min', second: 'sec', secs: 'sec',
        y: 'year', mo: 'month', d: 'day', h: 'hour', m: 'min', s: 'sec',
    };
    var norm = {};
    for (var k in dur)
        norm[aliases[k]||k] = dur[k];
    return norm;
}

E.describe_interval = function(_ms, decimals){
    var rmult = Math.pow(10, decimals||0);
    return _ms<2*ms.MIN ? Math.round(_ms/ms.SEC*rmult)/rmult+' sec' :
        _ms<2*ms.HOUR ? Math.round(_ms/ms.MIN*rmult)/rmult+' min' :
        _ms<2*ms.DAY ? Math.round(_ms/ms.HOUR*rmult)/rmult+' hours' :
        _ms<2*ms.WEEK ? Math.round(_ms/ms.DAY*rmult)/rmult+' days' :
        _ms<2*ms.MONTH ? Math.round(_ms/ms.WEEK*rmult)/rmult+' weeks' :
        _ms<2*ms.YEAR ? Math.round(_ms/ms.MONTH*rmult)/rmult+' months' :
        Math.round(_ms/ms.YEAR*rmult)/rmult+' years';
};

E.time_ago = function(d, until_date){
    var _ms = E.get(until_date)-E.get(d);
    if (_ms<ms.SEC)
        return 'right now';
    return E.describe_interval(_ms)+' ago';
};

E.ms_to_str = function(_ms){
    var s = ''+_ms;
    return s.length<=3 ? s+'ms' : s.slice(0, -3)+'.'+s.slice(-3)+'s';
};

E.parse = function(text, opt){
    opt = opt||{};
    if (opt.fmt)
        return E.strptime(text, opt.fmt);
    var d, a, i, v, _v, dir, _dir, amount, now = opt.now;
    now = !now ? new Date() : new Date(now);
    text = text.replace(/\s+/g, ' ').trim().toLowerCase();
    if (!text)
        return;
    if (text=='now')
        return now;
    if (!isNaN(d = E.get(text)))
        return d;
    d = now;
    a = text.split(' ');
    dir = a.includes('ago') ? -1 : a.includes('last') ? -1 :
        a.includes('next') ? 1 : undefined;
    for (i=0; i<a.length; i++)
    {
        v = a[i];
        if (/^(ago|last|next)$/.test(v));
        else if (v=='today')
            d = E.align(d, 'DAY');
        else if (v=='yesterday')
            d = E.align(+d-ms.DAY, 'DAY');
        else if (v=='tomorrow')
            d = E.align(+d+ms.DAY, 'DAY');
        else if ((_v = days_short_lc.indexOf(v))>=0)
            d = new Date(+E.align(d, 'WEEK')+_v*ms.DAY+(dir||0)*ms.WEEK);
        else if ((_v = days_long_lc.indexOf(v))>=0)
            d = new Date(+E.align(d, 'WEEK')+_v*ms.DAY+(dir||0)*ms.WEEK);
        else if (_v = /^([+-]?\d+)(?:([ymoinwdhs]+)(\d.*)?)?$/.exec(v))
        {
            if (amount!==undefined)
                return;
            amount = dir!==undefined ? Math.abs(+_v[1]) : +_v[1];
            if (_v[2])
            {
                a.splice(i+1, 0, _v[2]);
                if (_v[3])
                    a.splice(i+2, 0, _v[3]);
            }
            continue;
        }
        else if (/^([ywdhs]|years?|months?|mon?|weeks?|days?|hours?|minutes?|min|seconds?|sec)$/.test(v))
        {
            _v = v[0]=='m' && v[1]=='i' ? ms.MIN :
                v[0]=='y' ? ms.YEAR : v[0]=='m' && v[1]=='o' ? ms.MONTH :
                v[0]=='w' ? ms.WEEK :
                v[0]=='d' ? ms.DAY : v[0]=='h' ? ms.HOUR : ms.SEC;
            amount = amount===undefined ? 1 : amount;
            _dir = dir===undefined ? opt.dir||1 : dir;
            if (_v==ms.MONTH)
                d.setUTCMonth(d.getUTCMonth()+_dir*amount);
            else if (_v==ms.YEAR)
                d.setUTCFullYear(d.getUTCFullYear()+_dir*amount);
            else
                d = new Date(+d+_v*amount*_dir);
            amount = undefined;
        }
        else
            return;
        if (amount!==undefined)
            return;
    }
    if (amount!==undefined)
        return;
    return d;
};

E.strptime = function(str, fmt){
    function month(m){ return months_short_lc.indexOf(m.toLowerCase()); }
    var parse = {
        '%': ['%', function(){}, 0],
        a: ['[a-z]+', function(m){}, 0],
        A: ['[a-z]+', function(m){}, 0],
        b: ['[a-z]+', function(m){ d.setUTCMonth(month(m)); }, 2],
        B: ['[a-z]+', function(m){ d.setUTCMonth(month(m)); }, 2],
        y: ['[0-9]{2}', function(m){
            d.setUTCFullYear(+m+(m<70 ? 2000 : 1900)); }, 1],
        Y: ['[0-9]{4}', function(m){ d.setUTCFullYear(+m); }, 1],
        m: ['[0-9]{0,2}', function(m){ d.setUTCMonth(+m-1); }, 2],
        d: ['[0-9]{0,2}', function(m){ d.setUTCDate(+m); }, 3],
        H: ['[0-9]{0,2}', function(m){ d.setUTCHours(+m); }, 4],
        M: ['[0-9]{0,2}', function(m){ d.setUTCMinutes(+m); }, 5],
        S: ['[0-9]{0,2}', function(m){ d.setUTCSeconds(+m); }, 6],
        s: ['[0-9]+', function(m){ d = new Date(+m); }, 0],
        L: ['[0-9]{0,3}', function(m){ d.setUTCMilliseconds(+m); }, 7],
        z: ['[+-][0-9]{4}', function(m){
            var timezone = +m.slice(0, 3)*3600+m.slice(3, 5)*60;
            d = new Date(+d-timezone*1000);
        }, 8],
        Z: ['[a-z]{0,3}[+-][0-9]{2}:?[0-9]{2}|[a-z]{1,3}', function(m){
            m = /^([a-z]{0,3})(?:([+-][0-9]{2}):?([0-9]{2}))?$/i.exec(m);
            if (m[1]=='Z' || m[1]=='UTC')
                return;
            var timezone = +m[2]*3600+m[3]*60;
            d = new Date(+d-timezone*1000);
        }, 8],
        I: ['[0-9]{0,2}', function(m){ d.setUTCHours(+m); }, 4],
        p: ['AM|PM', function(m){
            if (d.getUTCHours()==12)
                d.setUTCHours(d.getUTCHours()-12);
            if (m.toUpperCase()=='PM')
                d.setUTCHours(d.getUTCHours()+12);
        }, 9],
    };
    var ff = [];
    var ff_idx = [];
    var re = new RegExp('^\\s*'+fmt.replace(/%(?:([a-zA-Z%]))/g,
        function(_, fd)
    {
        var d = parse[fd];
        if (!d)
            throw Error('Unknown format descripter: '+fd);
        ff_idx[d[2]] = ff.length;
        ff.push(d[1]);
        return '('+d[0]+')';
    })+'\\s*$', 'i');
    var matched = str.match(re);
    if (!matched)
        return;
    var d = new Date(0);
    for (var i=0; i<ff_idx.length; i++)
    {
        var idx = ff_idx[i];
        var fun = ff[idx];
        if (fun)
            fun(matched[idx+1]);
    }
    return d;
};

// tz in format shh:mm (for exmpl +01:00, -03:45)
E.apply_tz = function(d, tz, opt){
    if (!d)
        return d;
    d = E.get(d);
    tz = (tz||E.local_tz).replace(':', '');
    opt = opt||{};
    var timezone = +tz.slice(1, 3)*E.ms.HOUR+tz.slice(3, 5)*E.ms.MIN;
    var sign = tz.slice(0, 1) == '+' ? 1 : -1;
    if (opt.inverse)
        sign *= -1;
    return new Date(d.getTime()+sign*timezone);
};

var utc_local = {
    local: {
        getSeconds: function(d){ return d.getSeconds(); },
        getMinutes: function(d){ return d.getMinutes(); },
        getHours: function(d){ return d.getHours(); },
        getDay: function(d){ return d.getDay(); },
        getDate: function(d){ return d.getDate(); },
        getMonth: function(d){ return d.getMonth(); },
        getFullYear: function(d){ return d.getFullYear(); },
        getYearBegin: function(d){ return new Date(d.getFullYear(), 0, 1); }
    },
    utc: {
        getSeconds: function(d){ return d.getUTCSeconds(); },
        getMinutes: function(d){ return d.getUTCMinutes(); },
        getHours: function(d){ return d.getUTCHours(); },
        getDay: function(d){ return d.getUTCDay(); },
        getDate: function(d){ return d.getUTCDate(); },
        getMonth: function(d){ return d.getUTCMonth(); },
        getFullYear: function(d){ return d.getUTCFullYear(); },
        getYearBegin: function(d){ return new Date(Date.UTC(
            d.getUTCFullYear(), 0, 1)); }
    }
};

E.strftime = function(fmt, d, opt){
    opt = opt||{};
    d = E.get(d);
    var locale = opt.locale||E.locale;
    var formats = locale.formats||{};
    var tz = opt.timezone;
    var utc = opt.utc!==undefined ? opt.utc :
        opt.local!==undefined ? !opt.local :
        true;
    if (tz!=null)
    {
        utc = true;
        // ISO 8601 format timezone string, [-+]HHMM
        // Convert to the number of minutes and it'll be applied to the date
        // below.
        if (typeof tz=='string')
        {
            var sign = tz[0]=='-' ? -1 : 1;
            var hours = parseInt(tz.slice(1, 3), 10);
            var mins = parseInt(tz.slice(3, 5), 10);
            tz = sign*(60*hours+mins);
        }
        if (typeof tz=='number')
            d = new Date(+d+tz*60000);
    }
    var l = utc ? utc_local.utc : utc_local.local;
    var p = {d: d, utc: utc, l: l, locale: locale, formats: formats, tz: tz};
    return format(fmt, p);
};

// Most of the specifiers supported by C's strftime, and some from Ruby.
// Some other syntax extensions from Ruby are supported: %-, %_, and %0
// to pad with nothing, space, or zero (respectively).
function format(fmt, p){
    function replacer(_, c){
        var mod, padding;
        if (c.length==2)
        {
            mod = c[0];
            if (mod=='-') // omit padding
                padding = '';
            else if (mod=='_') // pad with space
                padding = ' ';
            else if (mod=='0') // pad with zero
                padding = '0';
            else // unrecognized, return the format
                return _;
            c = c[1];
        }
        return ext.hasOwnProperty(c) ? ext[c](p, padding) : c;
    }
    if ((fmt.length==2 || fmt.length==3) && fmt[0]=='%')
        return ''+replacer(fmt, fmt.slice(1));
    if (frequently_used.hasOwnProperty(fmt))
        return frequently_used[fmt](p);
    return fmt.replace(/%([-_0]?.)/g, replacer);
}

var frequently_used = {
    '%Y-%m-%d': function(p){ return ext.F(p); },
    '%Y_%m_%d': function(p){ return ext.Y(p)+'_'+ext.m(p)+'_'+ext.d(p); },
    '%Y-%m-%d %H:%M:%S': function(p){ return ext.F(p)+' '+ext.T(p); },
    '%H:%M': function(p){ return ext.R(p); },
    '%H:%M:%S': function(p){ return ext.T(p); },
    '%b-%Y': function(p){ return ext.b(p)+'-'+ext.Y(p); },
    '%d-%b': function(p){ return ext.d(p)+'-'+ext.b(p); },
    '%d-%b-%y': function(p){ return ext.d(p)+'-'+ext.b(p)+'-'+ext.y(p); },
    '%d-%b-%Y': function(p){ return ext.d(p)+'-'+ext.b(p)+'-'+ext.Y(p); },
    '%d-%m-%Y': function(p){ return ext.d(p)+'-'+ext.m(p)+'-'+ext.Y(p); },
    '%e-%b-%Y': function(p){ return ext.v(p); },
    '%B %Y': function(p){ return ext.B(p)+' '+ext.Y(p); },
    '%F %T': function(p){ return ext.F(p)+' '+ext.T(p); },
    '%F %R': function(p){ return ext.F(p)+' '+ext.R(p); },
};
var ext = {
    // Examples for new Date(0) in GMT
    A: function(p, padding){ // 'Thursday'
        return p.locale.days_long[p.l.getDay(p.d)]; },
    a: function(p, padding){ // 'Thu'
        return p.locale.days_short[p.l.getDay(p.d)]; },
    B: function(p, padding){ // 'January'
        return p.locale.months_long[p.l.getMonth(p.d)]; },
    b: function(p, padding){ // 'Jan'
        return p.locale.months_short[p.l.getMonth(p.d)]; },
    C: function(p, padding){ // '19'
        return padx(Math.floor(p.l.getFullYear(p.d)/100), padding); },
    D: function(p, padding){ // '01/01/70'
        return p.formats.D ? format(p.formats.D, p) :
            ext.m(p, padding)+'/'+
            ext.d(p, padding)+'/'+
            ext.y(p, padding);
    },
    d: function(p, padding){ // '01'
        return padx(p.l.getDate(p.d), padding); },
    e: function(p, padding){ // '01'
        return p.l.getDate(p.d); },
    F: function(p, padding){ // '1970-01-01'
        return p.formats.F ? format(p.formats.F, p) :
            ext.Y(p, padding)+'-'+
            ext.m(p, padding)+'-'+
            ext.d(p, padding);
    },
    H: function(p, padding){ // '00'
        return padx(p.l.getHours(p.d), padding); },
    h: function(p, padding){ // 'Jan'
        return p.locale.months_short[p.l.getMonth(p.d)]; },
    I: function(p, padding){ // '12'
        return padx(hours12(p.l.getHours(p.d)), padding); },
    j: function(p, padding){ // '000'
        var day = Math.ceil((+p.d-p.l.getYearBegin(p.d))/(1000*60*60*24));
        return pad(day, 3);
    },
    k: function(p, padding){ // ' 0'
        return padx(p.l.getHours(p.d), padding===undefined ? ' ' : padding); },
    L: function(p, padding){ // '000'
        return pad(p.d.getMilliseconds(), 3); },
    l: function(p, padding){ // '12'
        return padx(hours12(p.l.getHours(p.d)),
            padding===undefined ? ' ' : padding);
    },
    M: function(p, padding){ // '00'
        return padx(p.l.getMinutes(p.d), padding); },
    m: function(p, padding){ // '01'
        return padx(p.l.getMonth(p.d)+1, padding); },
    n: function(p, padding){ // '\n'
        return '\n'; },
    o: function(p, padding){ // '1st'
        return ''+p.l.getDate(p.d)+ord_str(p.l.getDate(p.d)); },
    P: function(p, padding){ // 'am'
        return (p.l.getHours(p.d)<12 ? p.locale.AM : p.locale.PM)
            .toLowerCase();
    },
    p: function(p, padding){ // 'AM'
        return p.l.getHours(p.d)<12 ? p.locale.AM : p.locale.PM; },
    R: function(p, padding){ // '00:00'
        return p.formats.R ? format(p.formats.R, p) :
            ext.H(p, padding)+':'+
            ext.M(p, padding);
    },
    r: function(p, padding){ // '12:00:00 AM'
        return p.formats.r ? format(p.formats.r, p) :
            ext.I(p, padding)+':'+
            ext.M(p, padding)+':'+
            ext.S(p, padding)+' '+
            ext.p(p, padding);
    },
    S: function(p, padding){ // '00'
        return padx(p.l.getSeconds(p.d), padding); },
    s: function(p, padding){ // '0'
        return Math.floor(+p.d/1000);
    },
    T: function(p, padding){ // '00:00:00'
        return p.formats.T ? format(p.formats.T, p) :
            ext.H(p, padding)+':'+
            ext.M(p, padding)+':'+
            ext.S(p, padding);
    },
    t: function(p, padding){ // '\t'
        return '\t'; },
    U: function(p, padding){ // '00'
        return padx(week_num(p.l, p.d, 'sunday'), padding);
    },
    u: function(p, padding){ // '4'
        var day = p.l.getDay(p.d);
        // 1 - 7, Monday is first day of the week
        return day==0 ? 7 : day;
    },
    v: function(p, padding){ // '1-Jan-1970'
        return p.formats.v ? format(p.formats.v, p) :
            ext.e(p, padding)+'-'+
            ext.b(p, padding)+'-'+
            ext.Y(p, padding);
    },
    W: function(p, padding){ // '00'
        return padx(week_num(p.l, p.d, 'monday'), padding);
    },
    w: function(p, padding){ // '4'. 0 Sunday - 6 Saturday
        return p.l.getDay(p.d); },
    Y: function(p, padding){ // '1970'
        return p.l.getFullYear(p.d); },
    y: function(p, padding){ // '70'
        return (''+p.l.getFullYear(p.d)).slice(-2); },
    Z: function(p, padding){ // 'GMT'
        if (p.utc)
            return 'GMT';
        var tz_string = p.d.toString().match(/\((\w+)\)/);
        return tz_string && tz_string[1] || '';
    },
    z: function(p, padding){ // '+0000'
        if (p.utc)
            return '+0000';
        var off = typeof p.tz=='number' ? p.tz : -p.d.getTimezoneOffset();
        return (off<0 ? '-' : '+')+pad(Math.abs(Math.trunc(off/60)), 2)+
            pad(off%60, 2);
    },
};

function hours12(hours){
    return hours==0 ? 12 : hours>12 ? hours-12 : hours;
}
function ord_str(n){
    var i = n % 10, ii = n % 100;
    if (ii>=11 && ii<=13 || i==0 || i>=4)
        return 'th';
    switch (i)
    {
    case 1: return 'st';
    case 2: return 'nd';
    case 3: return 'rd';
    }
}
function week_num(l, _d, first_weekday){
    // This works by shifting the weekday back by one day if we
    // are treating Monday as the first day of the week.
    var wday = l.getDay(_d);
    if (first_weekday=='monday')
        wday = wday==0 /* Sunday */ ? wday = 6 : wday-1;
    var yday = (_d-l.getYearBegin(_d))/ms.DAY;
    return Math.floor((yday + 7 - wday)/7);
}
// Default padding is '0' and default length is 2, both are optional.
function padx(n, padding, length){
    // padx(n, <length>)
    if (typeof padding=='number')
    {
        length = padding;
        padding = '0';
    }
    // Defaults handle padx(n) and padx(n, <padding>)
    if (padding===undefined)
        padding = '0';
    length = length||2;
    var s = ''+n;
    // padding may be an empty string, don't loop forever if it is
    if (padding)
        for (; s.length<length; s = padding + s);
    return s;
}

E.local_tz = E.strftime('%z', E.get(), {utc: false});

// For a string like '11:00-23:30', returns a function that checks whether a
// given date (moment in time) belongs to the set.
// Syntax notes:
// * ':00' is optional: '11-23'
// * several intervals: '12-14 16-18'
// * '10-12' includes exact 10:00 but excludes exact 12:00
// * 24:00 is the same as 0:00, 25:00 is the same as 1:00, etc
// * intervals wrap around midnight: '23-7' is the same as '23-24 0-7'
// * therefore, '0-0' and '0-24' include all times
// * all times are assumed in UTC
E.compile_schedule = function(expr){
    var re = /^(\d\d?)(?::(\d\d?))?-(\d\d?)(?::(\d\d?))?$/;
    var parts = expr.split(/\s+/);
    var intervals = [];
    for (var i = 0; i<parts.length; i++)
    {
        if (!parts[i])
            continue;
        var m = re.exec(parts[i]);
        if (!m)
            throw new Error('Schedule syntax error: '+expr);
        var from = m[1]*ms.HOUR, to = m[3]*ms.HOUR;
        if (m[2])
            from += m[2]*ms.MIN;
        if (m[4])
            to += m[4]*ms.MIN;
        intervals.push({from: from%ms.DAY, to: to%ms.DAY});
    }
    return function(d){
        var t = E.get(d) % ms.DAY;
        for (var j = 0; j<intervals.length; j++)
        {
            var interval = intervals[j];
            if (interval.from<interval.to)
            {
                if (t>=interval.from && t<interval.to)
                    return true;
            }
            else
            {
                if (t<interval.to || t>=interval.from)
                    return true;
            }
        }
        return false;
    };
};

E.timezone_offset = function(tz, dt){
    dt = dt || E.get();
    tz = dt.toLocaleString('en', {timeZone: tz, timeStyle: 'long'})
    .split(' ').slice(-1)[0];
    var dt_str = dt.toString();
    var offset = Date.parse(dt_str+' '+tz)-Date.parse(dt_str+' UTC');
    return offset/ms.MIN;
};

E.min = function(v1, v2){
    var min;
    for (var i=0; i<arguments.length; i++)
    {
        var v = arguments[i];
        if (!E.is_date_like(v))
            continue;
        v = date_get(v);
        if (min==null || v<min)
            min = v;
    }
    return min;
};

E.max = function(v1, v2){
    var max;
    for (var i=0; i<arguments.length; i++)
    {
        var v = arguments[i];
        if (!E.is_date_like(v))
            continue;
        v = date_get(v);
        if (max==null || v>max)
            max = v;
    }
    return max;
};

E.is_date_like = function(v){
    if (v instanceof Date)
        return true;
    if (Number.isFinite(v))
        return true;
    if (typeof v=='string')
    {
        return date_like_regexes.some(function(re){ return re.test(v); })
            && Number.isFinite(Date.parse(v));
    }
    return false;
};
var date_like_regexes = [
    /^\d{2}(\d{2})?[ /-](\d{2}|[a-z]{3,10})[ /-]\d{2}/i, // yy(yy)?-mm-dd
    /^\d{2}[ /-](\d{2}|[a-z]{3,10})[ /-]\d{2}(\d{2})?/i, // dd-mm-yy(yy)?
    /^(\d{2}|[a-z]{3,10})[ /-]\d{2}[ /-]\d{2}(\d{2})?/i, // mm-dd-yy(yy)?
];

var metronomes = {};
E.metronome = function(delay, cb){
    if (!metronomes.hasOwnProperty(delay))
    {
        metronomes[delay] = [];
        var t = setInterval(function(){
            metronomes[delay].forEach(function(f){ f(); });
        }, delay);
        if (is_node)
            t.unref();
        cb();
    }
    metronomes[delay].push(cb);
};

E.to_unix_secs = function(v){
    return Math.floor(+date_get(v)/E.ms.SEC);
};

return E; }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)); }());


/***/ }),

/***/ "./util/etask.js":
/*!***********************!*\
  !*** ./util/etask.js ***!
  \***********************/
/***/ ((module, exports, __webpack_require__) => {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
var module;
// LICENSE_CODE ZON ISC
'use strict'; /*jslint node:true, browser:true, es6: true*/
(function(){
var  process, zerr, assert;
var is_node = typeof module=='object' && module.exports && module.children &&
    typeof __webpack_require__!='function';
var is_rn = typeof global=='object' && !!global.nativeRequire ||
    typeof navigator=='object' && navigator.product=='ReactNative';
if (!is_node)
{
    if (is_rn)
    {
    }
    else
        ;
    process = {
        nextTick: function(fn){ setTimeout(fn, 0); },
        env: {},
    };
    // XXX romank: use zerr.js
    // XXX bahaa: require bext/pub/zerr.js for extensions
    if (!is_rn && self.hola && self.hola.zerr)
        zerr = self.hola.zerr;
    else
    {
        zerr = function(){ console.log.apply(console, arguments); };
        zerr.perr = zerr;
        zerr.debug = function(){};
        zerr.is = function(){ return false; };
        zerr.L = {DEBUG: 0};
    }
    if (!zerr.is)
        zerr.is = function(){ return false; };
}
else
{
    require('./config.js');
    process = global.process||require('_process');
    zerr = require('./zerr.js');
    assert = require('assert');
    ;
}
// XXX odin: normally this would only be run for !is_node, but 'who' unittests
// loads a stubbed assert
if (typeof assert!='function')
    assert = function(){}; // XXX romank: add proper assert
// XXX yuval: /util/events.js -> events when node 6 (support prependListener)
// is here
!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(/*! ../../../../../../../../../util/events.js */ "./util/events.js"), __webpack_require__(/*! ../../../../../../../../../util/array.js */ "./util/array.js"), __webpack_require__(/*! ../../../../../../../../../util/util.js */ "./util/util.js")], __WEBPACK_AMD_DEFINE_RESULT__ = (function(events, array, zutil){
const E = Etask;
const GEN_FN = 'GeneratorFunction';
const env = process.env, assign = Object.assign;
E.use_bt = +env.ETASK_BT;
E.root = new Set();
E.assert_extra = +env.ETASK_ASSERT_EXTRA; // to debug internal etask bugs
E.nextTick = process.nextTick;
// XXX arik/romank: hack, rm set_zerr, get zerzerrusing require
E.set_zerr = function(_zerr){ zerr = _zerr; };
E.events = new events();
var cb_pre, cb_post, cb_ctx, longcb_ms, perf_enable;
E.perf_stat = {};
// XXX romang: hack to import in react native
if (is_rn)
    E.etask = E;
function _cb_pre(et){ return {start: Date.now()}; }
function _cb_post(et, ctx){
    ctx = ctx||cb_ctx;
    var ms = Date.now()-ctx.start;
    if (longcb_ms && ms>longcb_ms)
    {
        zerr('long cb '+ms+'ms: '+et.get_name()+', '
            +et.funcs[et.cur_state].toString().slice(0, 128));
    }
    if (perf_enable)
    {
        var name = et.get_name();
        var perf = E.perf_stat[name] ||
            (E.perf_stat[name] = {ms: 0, n: 0, max: 0});
        if (perf.max<ms)
            perf.max = ms;
        perf.ms += ms;
        perf.n++;
    }
}
function cb_set(){
    if (longcb_ms || perf_enable)
    {
        cb_pre = _cb_pre;
        cb_post = _cb_post;
        cb_ctx = {start: Date.now()};
    }
    else
        cb_pre = cb_post = cb_ctx = undefined;
}
E.longcb = function(ms){
    longcb_ms = ms;
    cb_set();
};
E.perf = function(enable){
    if (arguments.length)
    {
        perf_enable = enable;
        cb_set();
    }
    return perf_enable;
};
E.longcb(+env.LONGCB);
E.perf(+env.ETASK_PERF);

function stack_get(){
    // new Error(): 200K per second
    // http://jsperf.com/error-generation
    // Function.caller (same as arguments.callee.caller): 2M per second
    // http://jsperf.com/does-function-caller-affect-preformance
    // http://jsperf.com/the-arguments-object-s-effect-on-speed/2
    var prev = Error.stackTraceLimit, err;
    Error.stackTraceLimit = 4;
    err = new Error();
    Error.stackTraceLimit = prev;
    return err;
}

function Etask(opt, states){
    if (!(this instanceof Etask))
    {
        if (Array.isArray(opt) || typeof opt=='function')
        {
            states = opt;
            opt = undefined;
        }
        opt = typeof opt=='string' && {name: opt} || opt || {};
        if (typeof states=='function' && states.constructor.name==GEN_FN)
            return E._generator(null, states, opt);
        return new Etask(opt, typeof states=='function' ? [states] : states);
    }
    assert(Array.isArray(states), 'states must be an array');
    // init fields
    this.name = opt.name;
    this.cancelable = opt.cancel;
    this.then_waiting = new Set();
    this.child = new Set();
    this.child_guess = new Set();
    this.cur_state = -1;
    this.next_state = -1;
    this.states_idx = {};
    this.tm_create = Date.now();
    this.use_retval = false;
    this.at_return = false;
    this.free = false;
    this._stack = Etask.use_bt ? stack_get() : undefined;
    this._finally = -1;
    this._cancel = -1;
    if (opt.zexit_on_err!=null)
        this.info.zexit_on_err = opt.zexit_on_err;
    if (opt.skip_err_metrics!=null)
        this.info.skip_err_metrics = opt.skip_err_metrics;
    // performance: set all rest fields to undefined
    this.error = this.running = this.at_continue = this.wait_timer =
    this.retval = this.down = this.up = this.parent = this._alarm =
    this.tm_completed = this.parent_type = this.parent_guess =
    this.wait_retval = this.generator = this.generator_ctor = undefined;
    const funcs = [];
    const types = [];
    for (let i=0; i<states.length; i++)
    {
        const func = states[i];
        assert(typeof func=='function', 'invalid state type');
        const type = this._get_state_type(func.name, undefined);
        if (type.label)
            this.states_idx[type.label] = i;
        if (type.finally)
        {
            assert(this._finally==-1, 'more than 1 finally$');
            this._finally = i;
        }
        if (type.cancel)
        {
            assert(this._cancel==-1, 'more than 1 cancel$');
            this._cancel = i;
        }
        funcs[i] = i==0 && opt.state0_args
            ? func.bind.apply(func, [this].concat(opt.state0_args))
            : func;
        types[i] = type;
    }
    // keep PACKED_ELEMENTS array type with capacity equal to length
    this.funcs = Array.from(funcs);
    this.states = Array.from(types);
    E.root.add(this);
    let in_run;
    if (opt.spawn_parent)
        this.spawn_parent(opt.spawn_parent);
    else if (opt.up)
        opt.up._set_down(this);
    else if (in_run = E.in_run_top())
        this._spawn_parent_guess(in_run);
    if (opt.init)
        opt.init.call(this);
    if (opt.async)
    {
        const wait_retval = this._set_wait_retval();
        E.nextTick(()=>{
            if (this.running===undefined)
                this._got_retval(wait_retval);
        });
    }
    else if (this._next())
        this._run();
    return this;
}
zutil.inherits(Etask, events.EventEmitter);

Object.defineProperty(E.prototype, 'info', {
    get: function(){
        if (!this._info)
            this._info = {};
        return this._info;
    },
    set: function(v){
        this._info = v;
    },
});

E.prototype._root_remove = function(){
    assert(!this.parent, 'cannot remove from root when has parent');
    if (!E.root.delete(this))
        assert(0, 'etask not in root\n'+E.ps({MARK: this}));
};

E.prototype._parent_remove = function(){
    if (this.up)
    {
        var up = this.up;
        this.up = this.up.down = undefined;
        if (up.tm_completed)
            up._check_free();
        return;
    }
    if (this.parent_guess)
        this._parent_guess_remove();
    if (!this.parent)
        return this._root_remove();
    if (!this.parent.child.delete(this))
    {
        assert(0, 'etask child not in parent\n'
            +E.ps({MARK: [['child', this], ['parent', this.parent]]}));
    }
    if (this.parent.tm_completed)
        this.parent._check_free();
    this.parent = undefined;
};

E.prototype._check_free = function(){
    if (this.down || this.child.size)
        return;
    this._parent_remove();
    this.free = true;
};

E.prototype._call_err = function(e){
    E.ef(e, this);
    // XXX derry: add assert(0, 'etask err in signal: '+e);
};
E.prototype.emit_safe = function(){
    try { this.emit.apply(this, arguments); }
    catch(e){ this._call_err(e); }
};
E.prototype._call_safe = function(state_fn){
    try { return state_fn.call(this); }
    catch(e){ this._call_err(e); }
};
E.prototype._complete = function(){
    if (zerr.is(zerr.L.DEBUG))
        zerr.debug(this.shortname()+': close');
    this.tm_completed = Date.now();
    this.parent_type = this.up ? 'call' : 'spawn';
    if (this.error)
        this.emit_safe('uncaught', this.error);
    if (this._finally!==-1)
    {
        var ret = this._call_safe(this.funcs[this._finally]);
        if (E.is_err(ret))
            this._set_retval(ret);
    }
    this.emit_safe('finally');
    this.emit_safe('ensure');
    if (this.error && !this.up && !this.parent && !this.parent_guess)
        E.events.emit('uncaught', this);
    if (this.parent)
        this.parent.emit('child', this);
    if (this.up && (this.down || this.child.size))
    {
        var up = this.up;
        this.up = this.up.down = undefined;
        this.parent = up;
        up.child.add(this);
    }
    this._check_free();
    this._del_wait_timer();
    this.del_alarm();
    this._ecancel_child();
    this.emit_safe('finally1');
    for (let v of this.then_waiting.values())
    {
        this.then_waiting.delete(v);
        v();
    }
};
E.prototype._next = function(rv){
    if (this.tm_completed)
        return false;
    const states = this.states;
    let state = this.at_return ? states.length :
        this.next_state!=-1 ? this.next_state : this.cur_state+1;
    this.retval = rv&&rv.ret;
    this.error = rv&&rv.err;
    if (this.error!==undefined)
    {
        if (zerr.on_exception)
            zerr.on_exception(this.error, this);
        if (this.cur_state>-1 && this.states[this.cur_state].try_catch)
        {
            this.use_retval = true;
            for (; state<states.length && states[state].sig; state++);
        }
        else
            for (; state<states.length && !states[state].catch; state++);
    }
    else
        for (; state<states.length && states[state].aux; state++);
    this.cur_state = state;
    this.next_state = -1;
    if (this.cur_state<states.length)
        return true;
    this._complete();
    return false;
};
E.prototype._handle_rv = function(rv){
    var wait_retval, _this = this, ret = rv.ret;
    if (ret===this.retval); // fast-path: retval already set
    else if (!ret);
    else if (ret instanceof Etask)
    {
        if (!ret.tm_completed)
        {
            this._set_down(ret);
            wait_retval = this._set_wait_retval();
            ret.then_waiting.add(function(){
                _this._got_retval(wait_retval, E.err_res(ret.error,
                    ret.retval));
            });
            return true;
        }
        rv.err = ret.error;
        rv.ret = ret.retval;
    }
    else if (ret instanceof Etask_err)
    {
        rv.err = ret.error;
        rv.ret = undefined;
    }
    else if (typeof ret.then=='function') // promise
    {
        wait_retval = this._set_wait_retval();
        ret.then(function(_ret){ _this._got_retval(wait_retval, _ret); },
            function(err){ _this._got_retval(wait_retval, E.err(err)); });
        return true;
    }
    // generator
    else if (typeof ret.next=='function' && typeof ret.throw=='function')
    {
        rv.ret = E._generator(ret, this.funcs[this.cur_state], {});
        return this._handle_rv(rv);
    }
    return false;
};
E.prototype._set_retval = function(ret){
    if (ret===this.retval && !this.error); // fast-path retval already set
    else if (!ret)
    {
        this.retval = ret;
        this.error = undefined;
    }
    else if (ret instanceof Etask)
    {
        if (ret.tm_completed)
        {
            this.retval = ret.retval;
            this.error = ret.error;
        }
    }
    else if (ret instanceof Etask_err)
    {
        this.retval = undefined;
        this.error = ret.error;
    }
    else if (typeof ret.then=='function'); // promise
    // generator
    else if (typeof ret.next=='function' && typeof ret.throw=='function');
    else
    {
        this.retval = ret;
        this.error = undefined;
    }
    return ret;
};

E.prototype._set_wait_retval = function(){
    return this.wait_retval = new Etask_wait(this, 'wait_int'); };
E.in_run = [];
E.in_run_top = function(){ return E.in_run[E.in_run.length-1]; };
E.prototype._run = function(){
    var rv = {ret: undefined, err: undefined};
    while (1)
    {
        var _cb_ctx;
        var arg = this.error && !this.use_retval ? this.error : this.retval;
        this.use_retval = false;
        this.running = true;
        rv.ret = rv.err = undefined;
        E.in_run.push(this);
        if (zerr.is(zerr.L.DEBUG))
            zerr.debug(this.shortname()+':S'+this.cur_state+': running');
        if (cb_pre)
            _cb_ctx = cb_pre(this);
        try { rv.ret = this.funcs[this.cur_state].call(this, arg); }
        catch(e){
            rv.err = e;
            if (rv.err instanceof Error)
                rv.err.etask = this;
        }
        if (cb_post)
            cb_post(this, _cb_ctx);
        this.running = false;
        E.in_run.pop();
        for (let vv of this.child_guess.values())
        {
            this.child_guess.delete(vv);
            vv.parent_guess = undefined;
        }
        if (rv.ret instanceof Etask_wait)
        {
            var wait_completed = false, wait = rv.ret;
            if (!this.at_continue && !wait.ready)
            {
                this.wait_retval = wait;
                if (wait.op=='wait_child')
                     wait_completed = this._set_wait_child(wait);
                if (wait.timeout)
                    this._set_wait_timer(wait.timeout);
                if (!wait_completed)
                    return;
                this.wait_retval = undefined;
            }
            rv.ret = this.at_continue ? this.at_continue.ret :
                wait.ready && !wait.completed ? wait.ready.ret : undefined;
            wait.completed = true;
        }
        this.at_continue = undefined;
        if (this._handle_rv(rv))
            return;
        if (!this._next(rv))
            return;
    }
};

E.prototype._set_down = function(down){
    if (this.down)
        assert(0, 'caller already has a down\n'+this.ps());
    if (down.parent_guess)
        down._parent_guess_remove();
    assert(!down.parent, 'returned etask already has a spawn parent');
    assert(!down.up, 'returned etask already has a caller parent, '
        + 'consider using wait_ext');
    down._parent_remove();
    this.down = down;
    down.up = this;
};

const state_type_cache = {};
E.prototype._get_state_type = function(name, on_fail){
    let type = state_type_cache[name];
    if (type)
        return type;
    type = state_type_cache[name] = new Etask_state_type();
    if (!name)
        return type;
    type.name = name;
    const n = name.split('$');
    if (n.length==1)
    {
        type.label = n[0];
        return type;
    }
    if (n.length>2)
        return type;
    if (n[1].length)
        type.label = n[1];
    const f = n[0].split('_');
    for (let j=0; j<f.length; j++)
    {
        if (f[j]=='try')
        {
            type.try_catch = true;
            if (j+1<f.length && f[j+1]=='catch')
                j++;
        }
        else if (f[j]=='catch')
            type['catch'] = true;
        else if (f[j]=='finally' || f[j]=='ensure')
            type.finally = true;
        else if (f[j]=='cancel')
            type.cancel = true;
        else
        {
            return void (on_fail||assert.bind(null, false))(
                'unknown func name '+name);
        }
    }
    if ((+(type.catch||type.try_catch))+(+type.finally)+(+type.cancel)>1)
    {
        return void (on_fail||assert.bind(null, false))(
            'invalid multiple state types');
    }
    type.sig = type.finally||type.cancel;
    type.aux = type.sig||type.catch;
    return type;
};
class Etask_state_type {
    constructor(){
        this.name = undefined;
        this.label = undefined;
        this.try_catch = false;
        this.catch = false;
        this.finally = false;
        this.cancel = false;
        this.sig = false;
        this.aux = false;
    }
}

E.prototype.spawn = function(child, replace){
    if (!(child instanceof Etask) && child && typeof child.then=='function')
    {
        var promise = child;
        child = new Etask({}, [function(){ return promise; }]);
    }
    if (!(child instanceof Etask)) // promise already completed?
    {
        this.emit('child', child);
        return child;
    }
    if (!replace && child.parent)
        assert(0, 'child already has a parent\n'+child.parent.ps());
    child.spawn_parent(this);
    return child;
};

E.prototype._spawn_parent_guess = function(parent){
    this.parent_guess = parent;
    parent.child_guess.add(this);
};
E.prototype._parent_guess_remove = function(){
    if (!this.parent_guess.child_guess.delete(this))
    {
        assert(0, 'etask not in parent_guess\n'+this.ps({MARK: this})+'\n'
            +E.ps({MARK: this}));
    }
    this.parent_guess = undefined;
};
E.prototype.spawn_parent = function(parent){
    if (this.up)
        assert(0, 'child already has an up\n'+this.up.ps());
    if (this.tm_completed && !this.parent)
        return;
    this._parent_remove();
    if (parent && parent.free)
        parent = undefined;
    if (!parent)
        return void E.root.add(this);
    parent.child.add(this);
    this.parent = parent;
};

E.prototype.set_state = function(name){
    var state = this.states_idx[name];
    if (state===undefined)
        assert(0, 'named func "'+name+'" not found');
    return this.next_state = state;
};

E.prototype.finally = function(cb){
    if (this.tm_completed)
        process.nextTick(cb);
    else
        this.prependListener('finally', cb);
};
E.prototype.goto_fn = function(name){
    return this.goto.bind(this, name); };
E.prototype.goto = function(name, promise){
    this.set_state(name);
    assert(!this.states[this.next_state].sig, 'goto to sig');
    return this.continue(promise);
};

E.prototype.loop = function(promise){
    this.next_state = this.cur_state;
    return promise;
};

E.prototype._set_wait_timer = function(timeout){
    var _this = this;
    this.wait_timer = setTimeout(function(){
        _this.wait_timer = undefined;
        if (_this._next({ret: undefined, err: 'timeout'}))
            _this._run();
    }, timeout);
};
E.prototype._del_wait_timer = function(){
    if (this.wait_timer)
        this.wait_timer = clearTimeout(this.wait_timer);
    this.wait_retval = undefined;
};

E.prototype._get_child_running = function(){
    for (let v of this.child.values())
    {
        if (!v.tm_completed)
            return v;
    }
};
E.prototype._set_wait_child = function(wait_retval){
    let {child, cond, rethrow} = wait_retval;
    if (cond && child!='any')
    {
        assert(0, 'condition supported only for "any" option, you can add '
            +'support if needed');
    }
    if (child=='any')
    {
        if (!this._get_child_running())
            return true;
        let wait_on = ()=>{
            this.once('child', _child=>{
                if (rethrow && E.is_err(_child))
                    return this._got_retval(wait_retval, _child);
                if (!cond || cond.call(_child, _child.retval))
                    return this._got_retval(wait_retval, {child: _child});
                if (!this._get_child_running())
                    return this._got_retval(wait_retval);
                wait_on();
            });
        };
        wait_on();
    }
    else if (child=='all')
    {
        if (!this._get_child_running())
            return true;
        let wait_on = ()=>{
            this.once('child', _child=>{
                if (rethrow && E.is_err(_child))
                    return this._got_retval(wait_retval, _child);
                if (!this._get_child_running())
                    return this._got_retval(wait_retval);
                wait_on();
            });
        };
        wait_on();
    }
    else
    {
        assert(child, 'no child provided');
        assert(this===child.parent, 'child does not belong to parent');
        if (child.tm_completed)
            return true;
        child.once('finally', ()=>this._got_retval(wait_retval, {child}));
    }
    this.emit_safe('wait_on_child');
    return false;
};

E.prototype._got_retval = function(wait_retval, res){
    if (this.wait_retval!==wait_retval || wait_retval.completed)
        return;
    wait_retval.completed = true;
    if (this._next(E._res2rv(res)))
        this._run();
};
E.prototype.continue_fn = function(){
    return this.continue.bind(this); };
E.continue_depth = 0;
E.prototype.continue = function(promise, sync){
    this.wait_retval = undefined;
    this._set_retval(promise);
    if (this.tm_completed)
        return promise;
    if (this.down)
        this.down._ecancel();
    this._del_wait_timer();
    var rv = {ret: promise, err: undefined};
    if (this.running)
    {
        this.at_continue = rv;
        return promise;
    }
    if (this._handle_rv(rv))
        return rv.ret;
    var _this = this;
    if (E.is_final(promise) &&
        (!E.continue_depth && !E.in_run.length || sync))
    {
        E.continue_depth++;
        if (this._next(rv))
            this._run();
        E.continue_depth--;
    }
    else // avoid high stack depth
    {
        E.nextTick(function(){
            if (_this._next(rv))
                _this._run();
        });
    }
    return promise;
};

E.prototype._ecancel = function(){
    if (this.tm_completed)
        return this;
    this.emit_safe('cancel');
    if (this._cancel!=-1)
        return this._call_safe(this.funcs[this._cancel]);
    if (this.cancelable)
        return this.return();
};

E.prototype._ecancel_child = function(){
    if (!this.child.size)
        return;
    // copy array, since ecancel has side affects and can modify array
    let children = Array.from(this.child.values());
    for (let child of children)
        child._ecancel();
};

E.prototype.return_fn = function(){
    return this.return.bind(this); };
E.prototype.return = function(promise){
    if (this.tm_completed)
        return this._set_retval(promise);
    this.at_return = true;
    this.next_state = -1;
    return this.continue(promise, true);
};

E.prototype.del_alarm = function(){
    var a = this._alarm;
    if (!a)
        return;
    clearTimeout(a.id);
    if (a.cb)
        this.removeListener('sig_alarm', a.cb);
    this._alarm = undefined;
};

E.prototype.upd_alarm = function(ms){
    var a = this._alarm;
    if (!a)
        return;
    var cb = a.cb;
    this.alarm(ms, cb);
};

E.prototype.inc_alarm = function(ms){
    var a = this._alarm;
    if (!a)
        return;
    var cb = a.cb;
    var left = this.alarm_left();
    this.alarm(ms+left, cb);
};

E.prototype.alarm_left = function(){
    var a = this._alarm;
    if (!a)
        return 0;
    return a.start+a.ms-Date.now();
};

E.prototype.alarm_elapsed = function(){
    var a = this._alarm;
    if (!a)
        return 0;
    return Date.now()-a.start;
};

E.prototype._operation_opt = function(opt){
    if (opt.goto)
        return {ret: this.goto(opt.goto, opt.ret)};
    if (opt.throw)
        return {ret: this.throw(opt.throw)};
    if (opt.return!==undefined)
        return {ret: this.return(opt.return)};
    if (opt.continue!==undefined)
        return {ret: this.continue(opt.continue)};
};

E.prototype.alarm = function(ms, cb){
    var _this = this, opt, a;
    if (cb && typeof cb!='function')
    {
        opt = cb;
        cb = function(){
            var v;
            if (!(v = _this._operation_opt(opt)))
                assert(0, 'invalid alarm cb opt');
            return v.ret;
        };
    }
    this.del_alarm();
    a = this._alarm = {ms: ms, cb: cb, start: Date.now()};
    a.id = setTimeout(function(){
        _this._alarm = undefined;
        _this.emit('sig_alarm');
    }, a.ms);
    if (cb)
        this.once('sig_alarm', cb);
};

class Etask_wait {
    constructor(et, op, timeout, child, cond, rethrow){
        this.timeout = timeout;
        this.et = et;
        this.op = op;
        this.child = child;
        this.cond = cond;
        // XXX: rethrow==true should probably be the default behavir
        this.rethrow = rethrow;
        this.ready = undefined;
        this.completed = false;
    }
    continue(res){
        if (this.completed)
            return;
        if (!this.et.wait_retval)
            return void(this.ready = {ret: res});
        if (this!==this.et.wait_retval)
            return;
        this.et.continue(res);
    }
    continue_fn(){ return this.continue.bind(this); }
    throw(err){ return this.continue(E.err(err)); }
    throw_fn(){ return this.throw.bind(this); }
}
E.prototype.wait = function(timeout){
    return new Etask_wait(this, 'wait', timeout); };
E.prototype.wait_child = function(child, timeout, cond, opt){
    if (typeof timeout=='function')
    {
        cond = timeout;
        opt = cond;
        timeout = 0;
    }
    else if (typeof timeout=='object')
    {
        cond = undefined;
        opt = timeout;
        timeout = 0;
    }
    return new Etask_wait(this, 'wait_child', timeout, child, cond,
        opt&&opt.rethrow);
};

E.prototype.throw_fn = function(err){
    return err ? this.throw.bind(this, err) : this.throw.bind(this); };
E.prototype.throw = function(err){
    return this.continue(E.err(err)); };

E.prototype.get_name = function(flags){
    /* anon: Context.<anonymous> (/home/yoni/zon1/pkg/util/test.js:1740:7)
     * with name: Etask.etask1_1 (/home/yoni/zon1/pkg/util/test.js:1741:11) */
    var stack = this._stack instanceof Error ? this._stack.stack.split('\n') :
        undefined;
    var caller;
    flags = flags||{};
    if (stack)
    {
        caller = /^ {4}at (.*)$/.exec(stack[4]);
        caller = caller ? caller[1] : undefined;
    }
    var names = [];
    if (this.name)
        names.push(this.name);
    if (caller && !(this.name && flags.SHORT_NAME))
        names.push(caller);
    if (!names.length)
        names.push('noname');
    return names.join(' ');
};

E.prototype.state_str = function(){
    return this.cur_state+(this.next_state>=0 ? '->'+this.next_state : ''); };

E.prototype.get_depth = function(){
    var i=0, et = this;
    for (; et; et = et.up, i++);
    return i;
};

function trim_space(s){
    if (s[s.length-1]!=' ')
        return s;
    return s.slice(0, -1);
}
function ms_to_str(ms){ // from date.js
    var s = ''+ms;
    return s.length<=3 ? s+'ms' : s.slice(0, -3)+'.'+s.slice(-3)+'s';
}
E.prototype.get_time_passed = function(){
    return ms_to_str(Date.now()-this.tm_create); };
E.prototype.get_time_completed = function(){
    return ms_to_str(Date.now()-this.tm_completed); };
E.prototype.get_info = function(){
    var info = this.info, s = '', _i;
    if (!info)
        return '';
    for (var i in info)
    {
        _i = info[i];
        if (!_i)
            continue;
        if (s!=='')
            s += ' ';
        if (typeof _i=='function')
            s += _i();
        else
            s += _i;
    }
    return trim_space(s);
};

// light-weight efficient etask/promise error value
function Etask_err(err){ this.error = err || new Error(); }
E.Etask_err = Etask_err;
E.err = function(err){ return new Etask_err(err); };
E.is_err = function(v){
    return v instanceof Etask && v.error!==undefined ||
        v instanceof Etask_err;
};
E.err_res = function(err, res){ return err ? E.err(err) : res; };
E._res2rv = function(res){
    return E.is_err(res) ? {ret: undefined, err: res.error}
        : {ret: res, err: undefined};
};
E.is_final = function(v){
    return !v || typeof v.then!='function' || v instanceof Etask_err ||
        v instanceof Etask && !!v.tm_completed;
};

// promise compliant .then() implementation for Etask and Etask_err.
// for unit-test comfort, also .otherwise(), .catch(), .ensure(), resolve() and
// reject() are implemented.
E.prototype.then = function(on_res, on_err){
    var _this = this;
    function on_done(){
        if (!_this.error)
            return !on_res ? _this.retval : on_res(_this.retval);
        return !on_err ? E.err(_this.error) : on_err(_this.error);
    }
    if (this.tm_completed)
    {
        return new Etask({name: 'then_completed'},
            [function(){ return on_done(); }]);
    }
    var then_wait = new Etask({name: 'then_wait'},
        [function(){ return this.wait(); }]);
    this.then_waiting.add(function(){
        try { then_wait.continue(on_done()); }
        catch(e){ then_wait.throw(e); }
    });
    return then_wait;
};
E.prototype.otherwise = E.prototype.catch = function(on_err){
    return this.then(null, on_err); };
E.prototype.ensure = function(on_ensure){
    return this.then(function(res){ on_ensure(); return res; },
        function(err){ on_ensure(); throw err; });
};
Etask_err.prototype.then = function(on_res, on_err){
    var _this = this;
    return new Etask({name: 'then_err'}, [function(){
        return !on_err ? E.err(_this.error) : on_err(_this.error);
    }]);
};
Etask_err.prototype.otherwise = Etask_err.prototype.catch = function(on_err){
    return this.then(null, on_err); };
Etask_err.prototype.ensure = function(on_ensure){
    this.then(null, function(){ on_ensure(); });
    return this;
};
E.resolve = function(v){ return new Etask({}, [function(){ return v; }]); };
E.reject = function(e){ return new Etask({}, [function(){ throw e; }]); };

E.prototype.wait_ext = function(promise){
    if (!promise || typeof promise.then!='function')
        return promise;
    var wait = this.wait();
    promise.then(wait.continue_fn(), wait.throw_fn());
    return wait;
};

E.prototype.shortname = function(){
    return this.name===undefined ? 'noname' : this.name;
};
E.prototype.longname = function(flags){
    flags = flags||{TIME: 1};
    var s = '', _s;
    if (this.running)
        s += 'RUNNING ';
    s += this.get_name(flags)+(!this.tm_completed ? '.'+this.state_str() : '')
        +' ';
    if (this.tm_completed)
        s += 'COMPLETED'+(flags.TIME ? ' '+this.get_time_completed() : '')+' ';
    if (flags.TIME)
        s += this.get_time_passed()+' ';
    if (_s = this.get_info())
        s += _s+' ';
    return trim_space(s);
};
E.prototype.stack = function(flags){
    var et = this, s = '';
    flags = assign({STACK: 1, RECURSIVE: 1, GUESS: 1}, flags);
    while (et)
    {
        var _s = et.longname(flags)+'\n';
        if (et.up)
            et = et.up;
        else if (et.parent)
        {
            _s = (et.parent_type=='call' ? 'CALL' : 'SPAWN')+' '+_s;
            et = et.parent;
        }
        else if (et.parent_guess && flags.GUESS)
        {
            _s = 'SPAWN? '+_s;
            et = et.parent_guess;
        }
        else
            et = undefined;
        if (flags.TOPDOWN)
            s = _s+s;
        else
            s += _s;
    }
    return s;
};
E.prototype._ps = function(pre_first, pre_next, flags){
    var i, s = '', task_trail, et = this, child_guess;
    if (++flags.limit_n>=flags.LIMIT)
        return flags.limit_n==flags.LIMIT ? '\nLIMIT '+flags.LIMIT+'\n': '';
    /* get top-most et */
    for (; et.up; et = et.up);
    /* print the sp frames */
    for (var first = 1; et; et = et.down, first = 0)
    {
        s += first ? pre_first : pre_next;
        first = 0;
        if (flags.MARK && (i = flags.MARK.sp.indexOf(et))>=0)
            s += (flags.MARK.name[i]||'***')+' ';
        s += et.longname(flags)+'\n';
        if (flags.RECURSIVE)
        {
            var stack_trail = et.down ? '.' : ' ';
            var child = et.child;
            if (flags.GUESS)
                child = new Set([...child, ...et.child_guess]);
            i = 0;
            for (let child_i of child.values())
            {
                task_trail = i<child.size-1 ? '|' : stack_trail;
                child_guess = child_i.parent_guess ? '\\? ' :
                    child_i.parent_type=='call' ? '\\> ' : '\\_ ';
                s += child_i._ps(pre_next+task_trail+child_guess,
                    pre_next+task_trail+'   ', flags);
                i++;
            }
        }
    }
    return s;
};
function ps_flags(flags){
    var m, _m;
    if (m = flags.MARK)
    {
        if (!Array.isArray(m))
            _m = {sp: [m], name: []};
        else if (!Array.isArray(flags.MARK[0]))
            _m = {sp: m, name: []};
        else
        {
            _m = {sp: [], name: []};
            for (var i=0; i<m.length; i++)
            {
                _m.name.push(m[i][0]);
                _m.sp.push(m[i][1]);
            }
        }
        flags.MARK = _m;
    }
}
E.prototype.ps = function(flags){
    flags = assign({STACK: 1, RECURSIVE: 1, LIMIT: 10000000, TIME: 1,
        GUESS: 1}, flags, {limit_n: 0});
    ps_flags(flags);
    return this._ps('', '', flags);
};
E._longname_root = function(){
    return (zerr.prefix ? zerr.prefix+'pid '+process.pid+' ' : '')+'root'; };
E.ps = function(flags){
    var s = '', task_trail;
    flags = assign({STACK: 1, RECURSIVE: 1, LIMIT: 10000000, TIME: 1,
        GUESS: 1}, flags, {limit_n: 0});
    ps_flags(flags);
    s += E._longname_root()+'\n';
    var child = Array.from(E.root.values());
    if (flags.GUESS)
    {
        child = [];
        E.root.forEach(root_i=>{
            if (!root_i.parent_guess)
                child.push(root_i);
        });
    }
    child.forEach((child_i, i)=>{
        task_trail = i<child.length-1 ? '|' : ' ';
        s += child_i._ps(task_trail+'\\_ ', task_trail+'   ', flags);
    });
    return s;
};

function assert_tree_unique(a){
    var i;
    for (i=0; i<a.length-1; i++)
        assert(!a.includes(a[i], i+1));
}
E.prototype._assert_tree = function(opt){
    var et;
    opt = opt||{};
    assert_tree_unique(this.child);
    assert(this.parent);
    if (this.down)
    {
        et = this.down;
        assert(et.up===this);
        assert(!et.parent);
        assert(!et.parent_guess);
        this.down._assert_tree(opt);
    }
    for (let _et of this.child.values())
    {
        assert(_et.parent===this);
        assert(!_et.parent_guess);
        assert(!_et.up);
        _et._assert_tree(opt);
    }
    if (this.child_guess.size)
        assert(E.in_run.includes(this));
    for (let _et of this.child_guess.values())
    {
        assert(_et.parent_guess===this);
        assert(!_et.parent);
        assert(!_et.up);
    }
};
E._assert_tree = function(opt){
    opt = opt||{};
    assert_tree_unique(E.root);
    for (let et of this.child.values())
    {
        assert(!et.parent);
        assert(!et.up);
        et._assert_tree(opt);
    }
};
E.prototype._assert_parent = function(){
    if (this.up)
        return assert(!this.parent && !this.parent_guess);
    assert(this.parent && this.parent_guess,
        'parent_guess together with parent');
    if (this.parent)
    {
        var child = this.parent ? this.parent.child : E.root;
        assert(child.has(this),
            'cannot find in parent '+(this.parent ? '' : 'root'));
    }
    else if (this.parent_guess)
    {
        assert(this.parent_guess.child_guess.has(this),
            'cannot find in parent_guess');
        assert(E.in_run.includes(this.parent_guess));
    }
};

E.prototype.return_child = function(){
    // copy array, since return() has side affects and can modify array
    var child = Array.from(this.child.values());
    for (var i=0; i<child.length; i++)
        child[i].return();
};

E.sleep = function(ms){
    var timer;
    ms = ms||0;
    return new Etask({name: 'sleep', cancel: true}, [function(){
        this.info.ms = ms+'ms';
        timer = setTimeout(this.continue_fn(), ms);
        return this.wait();
    }, function finally$(){
        '@jsdefender { localDeclarations: false }';
        clearTimeout(timer);
    }]);
};

var ebreak_obj = {ebreak: 1};
E.prototype.break = function(ret){
    return this.throw({ebreak: ebreak_obj, ret: ret}); };
E.for = function(cond, inc, opt, states){
    if (Array.isArray(opt) || typeof opt=='function')
    {
        states = opt;
        opt = undefined;
    }
    states = typeof states=='function' ? [states] : states;
    return new Etask({name: 'for', cancel: true, init: opt&&opt.init_parent},
    [function loop(){
        return !cond || cond.call(this);
    }, function try_catch$(res){
        '@jsdefender { localDeclarations: false }';
        if (!res)
            return this.return();
        return new Etask({name: 'for_iter', cancel: true, init: opt&&opt.init},
            states||[]);
    }, function(){
        if (this.error)
        {
            if (this.error.ebreak===ebreak_obj)
                return this.return(this.error.ret);
            return this.throw(this.error);
        }
        return inc && inc.call(this);
    }, function(){
        return this.goto('loop');
    }]);
};
E.for_each = function(obj, states){
    var keys = Object.keys(obj);
    var iter = {obj: obj, keys: keys, i: 0, key: undefined, val: undefined};
    function init_iter(){ this.iter = iter; }
    return E.for(function(){
            this.iter = this.iter||iter;
            iter.key = keys[iter.i];
            iter.val = obj[keys[iter.i]];
            return iter.i<keys.length;
        },
        function(){ return iter.i++; },
        {init: init_iter, init_parent: init_iter},
        states);
};
E.while = function(cond, states){ return E.for(cond, null, states); };

// all([opt, ]a_or_o)
E.all = function(a_or_o, ao2){
    var i, j, opt = {};
    if (ao2)
    {
        opt = a_or_o;
        a_or_o = ao2;
    }
    if (Array.isArray(a_or_o))
    {
        var a = Array.from(a_or_o);
        i = 0;
        return new Etask({name: 'all_a', cancel: true}, [function(){
            for (j=0; j<a.length; j++)
                this.spawn(a[j]);
        }, function try_catch$loop(){
            '@jsdefender { localDeclarations: false }';
            if (i>=a.length)
                return this.return(a);
            this.info.at = 'at '+i+'/'+a.length;
            var _a = a[i];
            if (_a instanceof Etask)
                _a.spawn_parent();
            return _a;
        }, function(res){
            if (this.error)
            {
                if (!opt.allow_fail)
                    return this.throw(this.error);
                res = E.err(this.error);
            }
            a[i] = res;
            i++;
            return this.goto('loop');
        }]);
    }
    else if (a_or_o instanceof Object)
    {
        var keys = Object.keys(a_or_o), o = {};
        i = 0;
        return new Etask({name: 'all_o', cancel: true}, [function(){
            for (j=0; j<keys.length; j++)
                this.spawn(a_or_o[keys[j]]);
        }, function try_catch$loop(){
            '@jsdefender { localDeclarations: false }';
            if (i>=keys.length)
                return this.return(o);
            var _i = keys[i], _a = a_or_o[_i];
            this.info.at = 'at '+_i+' '+i+'/'+keys.length;
            if (_a instanceof Etask)
                _a.spawn_parent();
            return _a;
        }, function(res){
            if (this.error)
            {
                if (!opt.allow_fail)
                    return this.throw(this.error);
                res = E.err(this.error);
            }
            o[keys[i]] = res;
            i++;
            return this.goto('loop');
        }]);
    }
    assert(0, 'invalid type');
};

E.all_limit = function(limit, arr_iter, cb){
    var at = 0;
    var iter = !Array.isArray(arr_iter) ? arr_iter : function(){
        if (at<arr_iter.length)
            return cb.call(this, arr_iter[at++]);
    };
    return new Etask({name: 'all_limit', cancel: true}, [function(){
        var next;
        if (!(next = iter.call(this)))
            return this.goto('done');
        if (E.is_err(next))
            return this.throw(next.error);
        var _this = this;
        if (typeof next.catch=='function')
            next.catch(function(e){ _this.throw(e); });
        this.spawn(next);
        this.loop();
        if (this.child.size>=limit)
            return this.wait_child('any', {rethrow: true});
    }, function done(){
        return this.wait_child('all', {rethrow: true});
    }]);
};

// _apply(opt, func[, _this], args)
// _apply(opt, object, method, args)
E._apply = function(opt, func, _this, args){
    var func_name;
    if (typeof _this=='string') // class with '.method' string call
    {
        if (_this[0]!='.')
            assert(0, 'invalid method '+_this);
        var method = _this.slice(1), _class = func;
        func = _class[method];
        _this = _class;
        if (!(_this instanceof Object))
            assert(0, 'invalid method .'+method);
        func_name = method;
    }
    else if (Array.isArray(_this) && !args)
    {
        args = _this;
        _this = null;
    }
    opt.name = opt.name||func_name||func.name;
    return new Etask(opt, [function(){
        var et = this, ret_sync, returned = 0;
        args = Array.from(args);
        args.push(function cb(err, res){
            if (typeof opt.ret_sync=='string' && !returned)
            {
                // hack to wait for result
                var a = arguments;
                returned++;
                return void E.nextTick(function(){ cb.apply(null, a); });
            }
            var nfn = opt.nfn===undefined || opt.nfn ? 1 : 0;
            if (opt.ret_o)
            {
                var o = {}, i;
                if (Array.isArray(opt.ret_o))
                {
                    for (i=0; i<opt.ret_o.length; i++)
                        o[opt.ret_o[i]] = arguments[i+nfn];
                }
                else if (typeof opt.ret_o=='string')
                    o[opt.ret_o] = array.slice(arguments, nfn);
                else
                    assert(0, 'invalid opt.ret_o');
                if (typeof opt.ret_sync=='string')
                    o[opt.ret_sync] = ret_sync;
                res = o;
            }
            else if (opt.ret_a)
                res = array.slice(arguments, nfn);
            else if (!nfn)
                res = err;
            et.continue(nfn ? E.err_res(err, res) : res);
        });
        ret_sync = func.apply(_this, args);
        if (Array.isArray(opt.ret_sync))
            opt.ret_sync[0][opt.ret_sync[1]] = ret_sync;
        returned++;
        return this.wait();
    }]);
};

// nfn_apply([opt, ]object, method, args)
// nfn_apply([opt, ]func, this, args)
E.nfn_apply = function(opt, func, _this, args){
    var _opt = {nfn: 1, cancel: 1};
    if (typeof opt=='function' || typeof func=='string')
    {
        args = _this;
        _this = func;
        func = opt;
        opt = _opt;
    }
    else
        opt = assign(_opt, opt);
    return E._apply(opt, func, _this, args);
};
// cb_apply([opt, ]object, method, args)
// cb_apply([opt, ]func, this, args)
E.cb_apply = function(opt, func, _this, args){
    var _opt = {nfn: 0};
    if (typeof opt=='function' || typeof func=='string')
    {
        args = _this;
        _this = func;
        func = opt;
        opt = _opt;
    }
    else
        opt = assign(_opt, opt);
    return E._apply(opt, func, _this, args);
};

E.prototype.continue_nfn = function(){
    return function(err, res){ this.continue(E.err_res(err, res)); }
    .bind(this);
};

E.augment = function(_prototype, method, e_method){
    var i, opt = {};
    if (method instanceof Object && !Array.isArray(method))
    {
        assign(opt, method);
        method = arguments[2];
        e_method = arguments[3];
    }
    if (Array.isArray(method))
    {
        if (e_method)
            opt.prefix = e_method;
        for (i=0; i<method.length; i++)
            E.augment(_prototype, opt, method[i]);
        return;
    }
    opt.prefix = opt.prefix||'e_';
    if (!e_method)
        e_method = opt.prefix+method;
    var fn = _prototype[method];
    _prototype[e_method] = function(){
        return E._apply({name: e_method, nfn: 1}, fn, this, arguments); };
};

E.wait = function(timeout){
    return new Etask({name: 'wait', cancel: true},
        [function(){ return this.wait(timeout); }]);
};
E.to_nfn = function(promise, cb, opt){
    return new Etask({name: 'to_nfn', async: true}, [function try_catch$(){
        '@jsdefender { localDeclarations: false }';
        return promise;
    }, function(res){
        var ret = [this.error];
        if (opt && opt.ret_a)
            ret = ret.concat(res);
        else
            ret.push(res);
        cb.apply(null, ret);
    }]);
};
function etask_fn(opt, states, push_this){
    if (Array.isArray(opt) || typeof opt=='function')
    {
        states = opt;
        opt = undefined;
    }
    let is_gen = typeof states=='function' && states.constructor.name==GEN_FN;
    let arg_start = +push_this;
    return function(){
        const _opt = assign({}, opt);
        _opt.state0_args = new Array(arg_start+arguments.length);
        _opt.state0_args[0] = this;
        for (var i=0; i<arguments.length; i++)
            _opt.state0_args[arg_start+i] = arguments[i];
        if (is_gen)
            return E._generator(null, states, _opt);
        return new Etask(_opt, typeof states=='function' ? [states] : states);
    };
}
E.fn = function(opt, states){ return etask_fn(opt, states, false); };
E._fn = function(opt, states){ return etask_fn(opt, states, true); };
E._generator = function(gen, ctor, opt){
    opt.name = opt.name || ctor && ctor.name || 'generator';
    opt.cancel = opt.cancel===undefined ? true : opt.cancel;
    let done = false;
    return new Etask(opt, [function(){
        this.generator = gen = gen||ctor.apply(this, opt.state0_args||[]);
        this.generator_ctor = ctor;
        return {ret: undefined, err: undefined};
    }, function try_catch$loop(rv){
        '@jsdefender { localDeclarations: false }';
        var res;
        try { res = rv.err ? gen.throw(rv.err) : gen.next(rv.ret); }
        catch(e){ return this.return(E.err(e)); }
        if (res.done)
        {
            done = true;
            return this.return(res.value);
        }
        return res.value;
    }, function(ret){
        return this.goto('loop', this.error ?
            {ret: undefined, err: this.error} : {ret: ret, err: undefined});
    }, function finally$(){
        '@jsdefender { localDeclarations: false }';
        // https://kangax.github.io/compat-table/es6/#test-generators_%GeneratorPrototype%.return
        // .return() supported only in node>=6.x.x
        if (!done && gen && gen.return)
            try { gen.return(); } catch(e){}
    }]);
};
E.ef = function(err, et){ // error filter
    if (zerr.on_exception)
        zerr.on_exception(err, et);
    return err;
};
// similar to setInterval
// opt==10000 (or opt.ms==10000) - call states every 10 seconds
// opt.mode=='smart' - default mode, like setInterval. If states take
//   longer than 'ms' to execute, next execution is delayed.
// opt.mode=='fixed' - always sleep 10 seconds between states
// opt.mode=='spawn' - spawn every 10 seconds
E.interval = function(opt, states){
    if (typeof opt=='number')
        opt = {ms: opt};
    if (!opt.mode || opt.mode=='smart')
        return interval_smart(opt, states);
    if (opt.mode=='fixed')
        return interval_fixed(opt, states);
    if (opt.mode=='spawn')
        return interval_spawn(opt, states);
    throw new Error('unexpected mode '+opt.mode);
};
const interval_smart = (opt, states)=>{
    const STATE_BEGIN = 0;
    const STATE_OPS = 1;
    const STATE_TIMER = 2;
    const STATE_DONE = 4;
    let state, w, timer, gap_timer;
    const init_parent = function(){
        w = this.wait();
        this.finally(()=>clearTimeout(timer));
    };
    const set_state = (for_et, flag)=>{
        if ((state = state|flag) != (STATE_OPS|STATE_TIMER))
            return;
        state = state|STATE_DONE;
        if (flag==STATE_TIMER)
            return void for_et.continue();
        if (gap_timer && zutil.is_timer_refresh)
            gap_timer.refresh();
        else
        {
            clearTimeout(gap_timer);
            gap_timer = setTimeout(for_et.continue_fn(), 0);
        }
    };
    return E.for(function(){
        state = STATE_BEGIN;
        if (timer && zutil.is_timer_refresh)
            timer.refresh();
        else
        {
            clearTimeout(timer);
            timer = setTimeout(()=>set_state(this, STATE_TIMER), opt.ms);
        }
        return true;
    }, function(){
        set_state(this, STATE_OPS);
        return w;
    }, {init_parent}, states);
};
const interval_fixed = (opt, states)=>{
    let w, timer;
    const init_parent = function(){
        w = this.wait();
        this.finally(()=>clearTimeout(timer));
    };
    return E.for(null, function(){
        if (timer && zutil.is_timer_refresh)
            timer.refresh();
        else
        {
            clearTimeout(timer);
            timer = setTimeout(this.continue_fn(), opt.ms);
        }
        return w;
    }, {init_parent}, states);
};
const interval_spawn = (opt, states)=>{
    let w, timer, stopped = false;
    const init = function(){
        w = this.wait();
        this.finally(()=>clearTimeout(timer));
    };
    states = typeof states=='function' ? [states] : states;
    return new Etask({name: 'interval_spawn', cancel: true, init},
        [function loop(){
            new Etask({}, [function try_catch$(){
                '@jsdefender { localDeclarations: false }';
                return new Etask({}, states);
            }, function(res){
                if (!this.error)
                    return;
                if (this.error.ebreak!==ebreak_obj)
                    return this.throw(this.error);
                stopped = true;
            }]);
        }, function(){
            if (stopped)
                return this.return();
            if (timer && zutil.is_timer_refresh)
                timer.refresh();
            else
            {
                clearTimeout(timer);
                timer = setTimeout(this.continue_fn(), opt.ms);
            }
            return w;
        }, function(){
            if (stopped) // stopped during sleep by prev long iteration
                return this.return();
            return this.goto('loop');
        }]);
};

E._class = function(cls){
    var proto = cls.prototype, keys = Reflect.ownKeys(proto);
    for (var i=0; i<keys.length; i++)
    {
        var key = keys[i];
        var descr = Object.getOwnPropertyDescriptor(proto, key);
        if (descr.get||descr.set)
            continue;
        var p = proto[key];
        if (typeof p=='function' && p.constructor.name==GEN_FN)
            proto[key] = E._fn(p);
    }
    return cls;
};
E.shutdown = function(){
    var prev;
    while (E.root.size)
    {
        var e = E.root.values().next().value;
        if (e==prev)
        {
            assert(e.tm_completed);
            zerr.zexit('etask root not removed after return - '+
                'fix non-cancelable child etask');
        }
        prev = e;
        e.return();
    }
};

E.race = function(ets){
    return new Etask({}, [function race(){
        if (!Array.isArray(ets))
            zerr.zexit('provided argument is not an array');
        if (!ets.length)
            return;
        var race_et = E.wait();
        var _this = this;
        function _child_error_handler(e){ race_et.throw(e); }
        var _race = new Etask({}, [
            function(){
                return E.for_each(ets, function(){
                    var et = this.iter.val;
                    _this.spawn(new Etask({}, [
                        function(){
                            this.on('uncaught', _child_error_handler);
                            return et;
                        },
                        function(res){ race_et.continue(res); },
                    ]));
                });
            },
            function(){ return race_et; },
        ]);
        _race.finally(function(){ _this.return_child(); });
        return _race;
    }]);
};

E.any = function(opt, ets){
    if (!ets)
    {
        ets = opt;
        opt = {};
    }
    opt=opt||{};
    opt.rethrow = opt.rethrow==undefined ? 1 : opt.rethrow;
    return new Etask({}, [function race(){
        if (!Array.isArray(ets))
            zerr.zexit('provided argument is not an array');
        var length = ets.length;
        if (!length)
            return;
        var race_et = E.wait();
        var errors = [];
        var _this = this;
        function _child_error_handler(e){
            errors.push(e);
            if (errors.length!=length)
                return;
            var err = new Error('aggregation error');
            err.errors = errors;
            if (opt.rethrow)
                race_et.throw(err);
            else
                race_et.continue();
        }
        var _race = new Etask({}, [
            function(){
                return E.for_each(ets, function(){
                    var et = this.iter.val;
                    var child = _this.spawn(new Etask({}, [
                        function(){
                            this.on('uncaught', _child_error_handler);
                            return et;
                        },
                        function(res){ race_et.continue(res); },
                    ]));
                    if (opt.timeout)
                        setTimeout(()=>child.throw('timeout'), opt.timeout);
                });
            },
            function(){ return race_et; },
        ]);
        _race.finally(function(){ _this.return_child(); });
        return _race;
    }]);
};

return Etask; }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)); }());


/***/ }),

/***/ "./util/events.js":
/*!************************!*\
  !*** ./util/events.js ***!
  \************************/
/***/ ((module, exports) => {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
var module;
/*jslint skip_file:true*/
(function(){

var is_node = typeof module=='object' && module.exports && module.children;
var is_rn = (typeof global=='object' && !!global.nativeRequire) ||
    (typeof navigator=='object' && navigator.product=='ReactNative');
if (!is_node && !is_rn)
    ;
else
    ;
!(__WEBPACK_AMD_DEFINE_ARRAY__ = [], __WEBPACK_AMD_DEFINE_RESULT__ = (function(){

/**
 * Minimal EventEmitter interface that is molded against the Node.js
 * EventEmitter interface.
 *
 * @constructor
 * @api public
 */
function EventEmitter(){ this._events = {}; }

/**
 * Return a list of assigned event listeners.
 *
 * @param {String} name The events that should be listed.
 * @returns {Array}
 * @api public
 */
EventEmitter.prototype.listeners = function listeners(name){
    var events = this._events && this._events[name] || [];
    var length = events.length, listeners = [], event;
    for (var i = 0; i<length; event = events[++i])
        listeners.push(events[i].fn);
    return listeners;
};

/**
 * Emit an event to all registered event listeners.
 *
 * @param {String} name The name of the event.
 * @returns {Boolean} Indication if we've emitted an event.
 * @api public
 */
EventEmitter.prototype.emit = function emit(name, a1, a2, a3, a4, a5){
    if (!this._events || !this._events[name])
        return false;
    var listeners = this._events[name], length = listeners.length;
    var len = arguments.length, event = listeners[0], args, i;
    if (length===1)
    {
        switch (len)
        {
        case 1:
            event.fn.call(event.context||this);
            break;
        case 2:
            event.fn.call(event.context||this, a1);
            break;
        case 3:
            event.fn.call(event.context||this, a1, a2);
            break;
        case 4:
            event.fn.call(event.context||this, a1, a2, a3);
            break;
        case 5:
            event.fn.call(event.context||this, a1, a2, a3, a4);
            break;
        case 6:
            event.fn.call(event.context||this, a1, a2, a3, a4, a5);
            break;
        default:
            for (i = 1, args = new Array(len-1); i<len; i++)
                args[i-1] = arguments[i];
            event.fn.apply(event.context||this, args);
        }
        if (event.once)
            remove_listener.apply(this, [name, event]);
    }
    else
    {
        for (i = 1, args = new Array(len-1); i<len; i++)
            args[i-1] = arguments[i];
        for (i = 0; i<length; event = listeners[++i])
        {
            event.fn.apply(event.context||this, args);
            if (event.once)
                remove_listener.apply(this, [name, event]);
        }
    }
    return true;
};

function add_listener(name, fn, opt){
    opt = opt||{};
    if (!this._events)
        this._events = {};
    if (!this._events[name])
        this._events[name] = [];
    var event = {fn: fn};
    if (opt.context)
        event.context = opt.context;
    if (opt.once)
        event.once = opt.once;
    if (opt.prepend)
        this._events[name].unshift(event);
    else
        this._events[name].push(event);
    return this;
}

function remove_listener(name, listener){
    if (!this._events || !this._events[name])
        return this;
    var listeners = this._events[name], events = [];
    var is_fn = typeof listener=='function';
    for (var i = 0, length = listeners.length; i<length; i++){
        if (!listener)
            continue;
        if (is_fn && listeners[i].fn!==listener ||
            !is_fn && listeners[i]!==listener)
        {
            events.push(listeners[i]);
        }
    }
    // reset the array, or remove it completely if we have no more listeners
    if (events.length)
        this._events[name] = events;
    else
        this._events[name] = null;
    return this;
}

/**
 * Register a new EventListener for the given event.
 *
 * @param {String} name Name of the event.
 * @param {Function} fn Callback function.
 * @param context The context of the function.
 * @api public
 */
EventEmitter.prototype.on = function on(name, fn, context){
    return add_listener.apply(this, [name, fn, {context: context}]); };

/**
 * Add an EventListener that's only called once.
 *
 * @param {String} name Name of the event.
 * @param {Function} fn Callback function.
 * @param context The context of the function.
 * @api public
 */
EventEmitter.prototype.once = function once(name, fn, context){
    return add_listener.apply(this, [name, fn,
        {context: context, once: true}]);
};

EventEmitter.prototype.prependListener = function prependListener(name, fn,
    context)
{
    return add_listener.apply(this, [name, fn, {context: context,
        prepend: true}]);
};

EventEmitter.prototype.prependOnceListener = function prependOnceListener(
    name, fn, context)
{
    return this.prependListener(name, fn, {context: context, prepend: true,
        once: true});
};

/**
 * Remove event listeners.
 *
 * @param {String} name The event we want to remove.
 * @param {Function} fn The listener that we need to find.
 * @api public
 */
EventEmitter.prototype.removeListener = function removeListener(name, fn){
    return remove_listener.apply(this, [name, fn]); };

/**
 * Remove all listeners or only the listeners for the specified event.
 *
 * @param {String} name The event want to remove all listeners for.
 * @api public
 */
EventEmitter.prototype.removeAllListeners = function removeAllListeners(name){
  if (!this._events)
      return this;
  if (name)
      this._events[name] = null;
  else
      this._events = {};
  return this;
};

// alias methods names because people roll like that
EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
EventEmitter.prototype.addListener = EventEmitter.prototype.on;

// this function doesn't apply anymore
EventEmitter.prototype.setMaxListeners = function setMaxListeners(){
  return this; };

EventEmitter.prototype.eventNames = function eventNames(){
    var _this = this;
    return Object.keys(this._events).filter(function(e){
        return _this._events[e]!==null; });
};

// expose the module
EventEmitter.EventEmitter = EventEmitter;
// XXX pavlo: don't exist in node sources, not used in our code, need to check
// external usages and remove
EventEmitter.EventEmitter2 = EventEmitter;
EventEmitter.EventEmitter3 = EventEmitter;

return EventEmitter; }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)); })();


/***/ }),

/***/ "./util/util.js":
/*!**********************!*\
  !*** ./util/util.js ***!
  \**********************/
/***/ ((module, exports, __webpack_require__) => {

var __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;
var module;
// LICENSE_CODE ZON ISC
'use strict'; /*jslint node:true, browser:true, es6:true*/
(function(){
var  node_util;
var is_node = typeof module=='object' && module.exports && module.children &&
    typeof __webpack_require__!='function';
var is_rn = typeof global=='object' && !!global.nativeRequire ||
    typeof navigator=='object' && navigator.product=='ReactNative';
if (is_rn)
{
}
else if (!is_node)
    ;
else
{
    node_util = require('util');
    ;
}
!(__WEBPACK_AMD_DEFINE_ARRAY__ = [__webpack_require__(/*! ../../../../../../../../../util/array.js */ "./util/array.js")], __WEBPACK_AMD_DEFINE_RESULT__ = (function(array){
var E = {};

E._is_mocha = undefined;
E.is_mocha = function(){
    if (E._is_mocha!==undefined)
        return E._is_mocha;
    if (typeof process!='undefined' && typeof process.env!='undefined')
        return E._is_mocha = process.env.IS_MOCHA||false;
    return E._is_mocha = false;
};

E.is_lxc = function(){ return is_node && +process.env.LXC; };

// refresh() was added in node 10, we need to support node 8 for webOS TV 5.0
// https://webostv.developer.lge.com/develop/guides/js-service-basics
E.is_timer_refresh = (()=>{
    let t = setTimeout(()=>{});
    clearTimeout(t);
    return !!t.refresh;
})();

E.f_mset = function(flags, mask, bits){ return flags&~mask | bits; };
E.f_lset = function(flags, bits, logic){
    return E.f_mset(flags, bits, logic ? bits : 0); };
E.f_meq = function(flags, mask, bits){ return (flags & mask)==bits; };
E.f_eq = function(flags, bits){ return (flags & bits)==bits; };
E.f_cmp = function(f1, f2, mask){ return (f1 & mask)==(f2 & mask); };
E.xor = function(a, b){ return !a != !b; };
E.div_ceil = function(a, b){ return Math.floor((a+b-1)/b); };
E.ceil_mul = function(a, b){ return E.div_ceil(a, b)*b; };
E.floor_mul = function(a, b){ return Math.floor(a/b)*b; };

E.range = function(x, a, b){ return x>=a && x<=b; };
E.range.ii = function(x, a, b){ return x>=a && x<=b; };
E.range.ie = function(x, a, b){ return x>=a && x<b; };
E.range.ei = function(x, a, b){ return x>a && x<=b; };
E.range.ee = function(x, a, b){ return x>a && x<b; };

E.clamp = function(lower_bound, value, upper_bound){
    if (value < lower_bound)
        return lower_bound;
    if (value < upper_bound)
        return value;
    return upper_bound;
};

E.revcmp = function(a, b){
    return a>b ? -1 : a<b ? 1 : 0; };

/* Union given objects, using fn to resolve conflicting keys */
E.union_with = function(fn /* [o1, [o2, [...]]]*/){
    var res = {}, args;
    if (arguments.length==2 && typeof arguments[1]=='object')
        args = arguments[1];
    else
        args = array.slice(arguments, 1);
    for (var i = 0; i < args.length; ++i)
    {
        for (var key in args[i])
        {
            var arg = args[i];
            res[key] = res.hasOwnProperty(key) ? fn(res[key], arg[key])
                : arg[key];
        }
    }
    return res;
};

function _clone_deep(obj){
    var i, n, ret;
    if (obj instanceof Array)
    {
        ret = new Array(obj.length);
        n = obj.length;
        for (i = 0; i < n; i++)
            ret[i] = obj[i] instanceof Object ? _clone_deep(obj[i]): obj[i];
        return ret;
    }
    else if (obj instanceof Date)
        return new Date(obj);
    else if (obj instanceof RegExp)
        return new RegExp(obj);
    else if (obj instanceof URL)
        return new URL(obj);
    else if (obj instanceof Function)
        return obj;
    ret = {};
    for (i in obj)
        ret[i] = obj[i] instanceof Object ? _clone_deep(obj[i]) : obj[i];
    return ret;
}

E.clone_deep = function(obj){
    if (!(obj instanceof Object))
        return obj;
    return _clone_deep(obj);
};

// assumptions & shortcuts:
// - only arrays & pojos will be deeply cloned
// - we accept the risk of having shallow copy of Date/RegExp/ObjectId/etc
// - we accept the risk of skipping hasOwnProperty checks
// - we accept the risk of skipping xxx.constructor edge cases (e.g. iframes)
// => result is about 10-100x faster than _.cloneDeep for large objects
E.fast_unsafe_clone_deep = function(orig){
    if (orig==null)
        return orig;
    var res = orig.constructor==Object ? Object.assign({}, orig)
        : orig.constructor==Array ? orig.slice()
        : orig;
    if (res!==orig)
    {
        var stack = new Array(2500), len = 0, obj, k, v;
        stack[len++] = res;
        while (len>0)
        {
            obj = stack[--len];
            for (k in obj)
            {
                v = obj[k];
                if (typeof v==='object' && v!==null)
                {
                    if (v.constructor===Object)
                        obj[k] = stack[len++] = Object.assign({}, v);
                    else if (v.constructor===Array)
                        obj[k] = stack[len++] = v.slice();
                }
            }
        }
    }
    return res;
};

// prefer to normally Object.assign() instead of extend()
E.extend = function(obj){ // like _.extend
    for (var i=1; i<arguments.length; i++)
    {
        var source = arguments[i];
        if (!source)
            continue;
        for (var prop in source)
            obj[prop] = source[prop];
    }
    return obj;
};

E.is_object = function(obj){
    return obj && obj.constructor==Object;
};

E.extend_deep = function(obj){
    if (!E.is_object(obj))
        return obj;
    for (var i=1; i<arguments.length; i++)
    {
        var source = arguments[i];
        if (!source)
            continue;
        for (var prop in source)
        {
            if (E.is_object(source[prop]) && E.is_object(obj[prop]))
                E.extend_deep(obj[prop], source[prop]);
            else
                obj[prop] = source[prop];
        }
    }
    return obj;
};
E.extend_deep_del_null = function(obj){
    for (var i=1; i<arguments.length; i++)
    {
        var source = arguments[i];
        if (!source)
            continue;
        for (var prop in source)
        {
            if (E.is_object(source[prop]))
            {
                if (!E.is_object(obj[prop]))
                    obj[prop] = {};
                E.extend_deep_del_null(obj[prop], source[prop]);
            }
            else if (source[prop]==null)
                delete obj[prop];
            else
                obj[prop] = source[prop];
        }
    }
    return obj;
};

E.defaults = function(obj){ // like _.defaults
    if (!obj)
        obj = {};
    for (var i=1; i<arguments.length; i++)
    {
        var source = arguments[i];
        if (obj===undefined)
            continue;
        for (var prop in source)
        {
            if (obj[prop]===undefined)
                obj[prop] = source[prop];
        }
    }
    return obj;
};
E.defaults_deep = function(obj){
    if (obj!==undefined && !E.is_object(obj))
        return obj;
    for (var i=1; i<arguments.length; i++)
    {
        var source = arguments[i];
        if (obj===undefined)
            obj = E.clone_deep(source);
        else if (E.is_object(source))
        {
            for (var prop in source)
            {
                var s = source[prop], d = obj[prop];
                if (d===undefined)
                    obj[prop] = E.clone_deep(s);
                else
                    E.defaults_deep(d, s);
            }
        }
    }
    return obj;
};

E.clone = function(obj){ // like _.clone
    if (!(obj instanceof Object))
        return obj;
    if (obj instanceof Array)
    {
        var a = new Array(obj.length);
        for (var i=0; i<obj.length; i++)
            a[i] = obj[i];
        return a;
    }
    return E.extend({}, obj);
};

E.freeze_deep = function(obj){
    if (typeof obj=='object')
    {
        for (var prop in obj)
        {
            if (obj.hasOwnProperty(prop))
                E.freeze_deep(obj[prop]);
        }
    }
    return Object.freeze(obj);
};

// Limitations:
// We know that not every data type can be reliably compared for equivalence
// (other than with ===). In equal_deep, we try to be conservative, returning
// false when we cannot be sure. Functions, however, are compared by their
// string serializations, which can lead to conflation of distinct closures.
// Cyclic references are not supported (cause a stack overflow).
E.equal_deep = function(a, b){
    var i;
    if (a===b)
        return true;
    if (!a || !b || a.constructor!==b.constructor)
        return false;
    if (a instanceof Function || a instanceof RegExp)
        return a.toString()==b.toString();
    if (a instanceof Date)
        return +a == +b;
    if (Array.isArray(a))
    {
        if (a.length!=b.length)
            return false;
        for (i = 0; i<a.length; i++)
        {
            if (!E.equal_deep(a[i], b[i]))
                return false;
        }
        return true;
    }
    if (E.is_object(a))
    {
        var a_keys = Object.keys(a), b_keys = Object.keys(b);
        if (a_keys.length!=b_keys.length)
            return false;
        for (i = 0; i<a_keys.length; i++)
        {
            var key = a_keys[i];
            if (!E.equal_deep(a[key], b[key]))
                return false;
        }
        return true;
    }
    return false;
};

// like _.map() except returns object, not array
E.map_obj = function(obj, fn){
    var ret = {};
    for (var i in obj)
        ret[i] = fn(obj[i], i, obj);
    return ret;
};

// recursivelly recreate objects with keys added in order
E.sort_obj = function(obj, fn){
    if (obj instanceof Array || !(obj instanceof Object))
        return obj;
    var ret = {}, keys = Object.keys(obj).sort(fn);
    for (var i=0; i<keys.length; i++)
        ret[keys[i]] = E.sort_obj(obj[keys[i]], fn);
    return ret;
};

// an Object equivalent of Array.prototype.forEach
E.forEach = function(obj, fn, _this){
    for (var i in obj)
        fn.call(_this, obj[i], i, obj);
};
// an Object equivalent of Array.prototype.find
E.find = function(obj, fn, _this){
    for (var i in obj)
    {
        if (fn.call(_this, obj[i], i, obj))
            return obj[i];
    }
};
E.find_prop = function(obj, prop, val){
    return E.find(obj, function(o){ return o[prop]===val; }); };
E.isspace = function(c){ return /\s/.test(c); };
E.isdigit = function(c){ return c>='0' && c<='9'; };
E.isalpha = function(c){ return c>='a'&&c<='z' || c>='A'&&c<='Z'; };
E.isalnum = function(c){ return E.isdigit(c)||E.isalpha(c); };

E.obj_pluck = function(obj, prop){
    var val = obj[prop];
    delete obj[prop];
    return val;
};

// Object.keys() does not work on prototype
E.proto_keys = function(proto){
    var keys = [];
    for (var i in proto)
        keys.push(i);
    return keys;
};

E.values = function(obj){
    var values = [];
    for (var i in obj)
        values.push(obj[i]);
    return values;
};

E.path = function(path){
    if (Array.isArray(path))
        return path;
    path = ''+path;
    if (!path)
        return [];
    return path.split('.');
};
E.get = function(o, path, def){
    path = E.path(path);
    for (var i=0; i<path.length; i++)
    {
        // XXX vladimir/ron: decide on implementation without in operator
        if (!o || typeof o!='object'&&typeof o!='function' || !(path[i] in o))
            return def;
        o = o[path[i]];
    }
    return o;
};
E.set = function(o, path, value){
    var orig = o;
    path = E.path(path);
    for (var i=0; i<path.length-1; i++)
    {
        var p = path[i];
        o = o[p] || (o[p] = {});
    }
    o[path[path.length-1]] = value;
    return orig;
};
E.unset = function(o, path){
    path = E.path(path);
    for (var i=0; i<path.length-1; i++)
    {
        var p = path[i];
        if (!o[p])
            return;
        o = o[p];
    }
    delete o[path[path.length-1]];
};
var has_unique = {};
E.has = function(o, path){ return E.get(o, path, has_unique)!==has_unique; };

E.own = function(o, prop){
    return o!=null && Object.prototype.hasOwnProperty.call(o, prop); };

E.bool_lookup = function(a, split){
    var ret = {}, i;
    if (typeof a=='string')
        a = a.split(split||/\s/);
    for (i=0; i<a.length; i++)
        ret[a[i]] = true;
    return ret;
};

E.clone_inplace = function(dst, src){
    if (dst===src)
        return dst;
    if (Array.isArray(dst))
    {
        for (var i=0; i<src.length; i++)
            dst[i] = src[i];
        dst.splice(src.length);
    }
    else if (typeof dst=='object')
    { /* saving strict items order */
        Object.keys(dst).forEach(x=>delete dst[x]);
        Object.entries(src).forEach(([k, v])=>dst[k] = v);
    }
    return dst;
};

if (node_util && node_util.inherits)
    E.inherits = node_util.inherits;
else
{
    // implementation from node.js 'util' module
    E.inherits = function inherits(ctor, superCtor){
        ctor.super_ = superCtor;
        ctor.prototype = Object.create(superCtor.prototype,
            {constructor: {value: ctor, enumerable: false, writable: true,
            configurable: true}});
    };
}

// ctor must only have one prototype level
// XXX vladislav: ES6 class is not supported for ctor
E.inherit_init = function(obj, ctor, params){
    var orig_proto = Object.getPrototypeOf(obj);
    var ctor_proto = Object.assign({}, ctor.prototype);
    Object.setPrototypeOf(ctor_proto, orig_proto);
    Object.setPrototypeOf(obj, ctor_proto);
    return ctor.apply(obj, params);
};

E.pick = function(obj){
    var i, j, o = {};
    for (i=1; i<arguments.length; i++)
    {
        var fields = E.ensure_array(arguments[i]);
        for (j=0; j<fields.length; j++)
        {
            if (E.own(obj, fields[j]))
                o[fields[j]] = obj[fields[j]];
        }
    }
    return o;
};

// like _.pickBy
E.pick_by = function(obj, cb){
    var k, o = {};
    for (k in obj)
    {
        if (typeof obj[k] == 'object' && !Array.isArray(obj[k]))
            o[k] = E.pick_by(obj[k], cb);
        else if (cb(obj[k], k))
            o[k] = obj[k];
    }
    return o;
};

// subset of _.omit
E.omit = function(obj, omit){
    var i, o = {};
    obj = Object(obj);
    for (i in obj)
    {
        if (!omit.includes(i))
            o[i] = obj[i];
    }
    return o;
};

E.escape_dotted_keys = function(obj, repl){
    if (!Array.isArray(obj) && !E.is_object(obj))
        return obj;
    repl = repl||'_';
    for (var prop in obj)
    {
        if (E.own(obj, prop))
        {
            var new_prop = prop.replace(/\./g, repl);
            if (prop != new_prop)
            {
                obj[new_prop] = obj[prop];
                delete obj[prop];
            }
            if (Array.isArray(obj[new_prop]))
            {
                obj[new_prop].forEach(function(e){
                    E.escape_dotted_keys(e, repl);
                });
            }
            else if (E.is_object(obj[new_prop]))
                E.escape_dotted_keys(obj[new_prop], repl);
        }
    }
};

E.ensure_array = function(v, split){
    if (v==null || Array.isArray(v))
        return v||[];
    if (split && typeof v=='string')
        return v.split(split==true ? /[\s,]+/ : split).filter(Boolean);
    return [v];
};

E.reduce_obj = function(coll, key_cb, val_cb, merge_cb){
    if (coll==null)
        return {};
    if (val_cb===undefined && key_cb!=null && (key_cb.key||key_cb.value))
    {
        merge_cb = key_cb.merge;
        val_cb = key_cb.value;
        key_cb = key_cb.key;
    }
    key_cb = get_map_fn(key_cb);
    val_cb = get_map_fn(val_cb);
    var obj = {};
    if (Array.isArray(coll))
    {
        coll.forEach(function(item, i){
            var k = key_cb(item, i), v = val_cb(item, i);
            if (k===undefined || v===undefined)
                return;
            if (obj[k]!==undefined && merge_cb)
                v = merge_cb(obj[k], v);
            obj[k] = v;
        });
    }
    else if (typeof coll=='object')
    {
        Object.keys(coll).forEach(function(i){
            var k = key_cb(coll[i], i), v = val_cb(coll[i], i);
            if (k===undefined || v===undefined)
                return;
            if (obj[k]!==undefined && merge_cb)
                v = merge_cb(obj[k], v);
            obj[k] = v;
        });
    }
    return obj;
};

E.group_by = function(coll, key_cb, val_cb){
    var inner_val_cb = get_map_fn(val_cb);
    val_cb = function(it){ return [inner_val_cb(it)]; };
    var merge_cb = function(a, b){ return a.concat(b); };
    return E.reduce_obj(coll, key_cb, val_cb, merge_cb);
};

E.flatten_obj = function(obj){
    if (!E.is_object(obj) && !Array.isArray(obj))
        return obj;
    var res = {}, k, keys = Object.keys(obj);
    for (var i = 0; i < keys.length; i++)
    {
        k = keys[i];
        if (!E.is_object(obj[k]) && !Array.isArray(obj[k]))
            res[k] = obj[k];
        else
        {
            var o = E.flatten_obj(obj[k]), _keys = Object.keys(o);
            for (var j = 0; j < _keys.length; j++)
                res[k+'_'+_keys[j]] = o[_keys[j]];
        }
    }
    return res;
};

E.pairwise = function(coll, opt){
    if (!Array.isArray(coll) || coll.length<2)
        return;
    opt = opt||{};
    var res = [];
    for (var i = 0; i < coll.length; i++)
    {
        for (var j = i+1; j < coll.length; j++)
        {
            if (opt.balanced)
                res.push((i+j)%2 ? [coll[i], coll[j]] : [coll[j], coll[i]]);
            else
                res.push([coll[i], coll[j]]);
        }
    }
    return res;
};

E.stackless_error = function(msg, extra, Err_f){
    if (!Err_f && typeof extra=='function')
    {
        Err_f = extra;
        extra = undefined;
    }
    Err_f = Err_f || Error;
    const old_lmt = Error.stackTraceLimit;
    Error.stackTraceLimit = 0;
    const err = Object.assign(new Err_f(msg), extra);
    Error.stackTraceLimit = old_lmt;
    return err;
};

E.omit_falsy_props = function(o){
    return Object.fromEntries(Object.entries(o).filter(function(arg){
        return ![null, undefined, ''].includes(arg[1]);
    }));
};

// XXX: drop once jshint version supports BigInt (esversion >= 11)
/* jshint -W119 */
E.object_sizeof = obj=>Buffer.byteLength(
    JSON.stringify(obj, (_k, v)=>typeof v=='bigint' ? Number(v) : v));
/* jshint +W119 */

function get_map_fn(v){
    if (v==null)
        return function(it){ return it; };
    if (typeof v=='function')
        return v;
    var path = E.path(v);
    if (!path.length)
        return function(it){ return it; };
    if (path.length==1)
        return function(it){ return it==null ? it : it[path[0]]; };
    return function(it){ return E.get(it, path); };
}

return E; }).apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__)); }());


/***/ }),

/***/ "./src/util/consts.js":
/*!****************************!*\
  !*** ./src/util/consts.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CHROME_STORE_LINK": () => (/* binding */ CHROME_STORE_LINK),
/* harmony export */   "IPC": () => (/* binding */ IPC),
/* harmony export */   "LUMTEST_URL": () => (/* binding */ LUMTEST_URL),
/* harmony export */   "PATHS": () => (/* binding */ PATHS),
/* harmony export */   "PROXY_ERRORS": () => (/* binding */ PROXY_ERRORS),
/* harmony export */   "RATING_URL": () => (/* binding */ RATING_URL),
/* harmony export */   "RULES": () => (/* binding */ RULES)
/* harmony export */ });
/* harmony import */ var _util_date_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../../../../../util/date.js */ "./util/date.js");
/* harmony import */ var _util_date_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_util_date_js__WEBPACK_IMPORTED_MODULE_0__);
var module;
// LICENSE_CODE ZON
'use strict'; /*jslint browser:true, es6:true*/

var APP_ID = 'efohiadmkaogdhibjbmeppjpebenaool';
var CHROME_STORE_LINK = 'https://chrome.google.com/webstore/detail/' + 'luminati/';
var RATING_URL = 'https://chrome.google.com/webstore/detail/' + 'luminati/' + APP_ID;
var LUMTEST_URL = 'http://lumtest.com/echo.json';
var PROXY_ERRORS = {
  ip_forbidden: 'Auth Failed (code: ip_forbidden)',
  peers_unavailable: 'Proxy Error: No peers available',
  city_unavailable: 'Proxy Error: We do not have IPs in the city'
};
var IPC = {
  MESSAGES: {
    ECHO: 'echo',
    HEARTBEAT: 'heartbeat',
    READY: 'ready',
    BG_LUM: 'bg_lum',
    ICON: 'icon'
  },
  IDS: {
    BG: 'bg',
    POPUP: 'popup',
    OFFSCREEN: 'offscreen',
    ANY: 'any'
  },
  HEARTBEAT_INTERVAL: 50 * (_util_date_js__WEBPACK_IMPORTED_MODULE_0___default().ms.MS)
};
var PATHS = {
  OFFSCREEN: 'offscreen.html'
};
var RULES = {
  HEADERS: {
    BP: {
      id: 2,
      priority: 1,
      action: {
        type: 'modifyHeaders',
        responseHeaders: []
      },
      condition: {
        resourceTypes: ['main_frame']
      }
    }
  }
};

/***/ }),

/***/ "./src/util/ipc.js":
/*!*************************!*\
  !*** ./src/util/ipc.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ IPC_router)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/classPrivateFieldGet */ "./node_modules/@babel/runtime/helpers/esm/classPrivateFieldGet.js");
/* harmony import */ var _babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/classPrivateFieldSet */ "./node_modules/@babel/runtime/helpers/esm/classPrivateFieldSet.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _util_etask_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../../../../../../util/etask.js */ "./util/etask.js");
/* harmony import */ var _util_etask_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_util_etask_js__WEBPACK_IMPORTED_MODULE_5__);





function _classPrivateMethodInitSpec(obj, privateSet) { _checkPrivateRedeclaration(obj, privateSet); privateSet.add(obj); }
function _classPrivateFieldInitSpec(obj, privateMap, value) { _checkPrivateRedeclaration(obj, privateMap); privateMap.set(obj, value); }
function _checkPrivateRedeclaration(obj, privateCollection) { if (privateCollection.has(obj)) { throw new TypeError("Cannot initialize the same private elements twice on an object"); } }
function _classPrivateMethodGet(receiver, privateSet, fn) { if (!privateSet.has(receiver)) { throw new TypeError("attempted to get private field on non-instance"); } return fn; }
var module;
// LICENSE_CODE ZON
'use strict'; /*jslint browser:true, es9:true, react:true*/ /*global chrome*/

var _self = /*#__PURE__*/new WeakMap();
var _listeners = /*#__PURE__*/new WeakMap();
var _send = /*#__PURE__*/new WeakSet();
var IPC_router = /*#__PURE__*/function () {
  function IPC_router(name) {
    (0,_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, IPC_router);
    _classPrivateMethodInitSpec(this, _send);
    _classPrivateFieldInitSpec(this, _self, {
      writable: true,
      value: null
    });
    _classPrivateFieldInitSpec(this, _listeners, {
      writable: true,
      value: new Map()
    });
    if (!name) throw 'IPC_router name param required';
    (0,_babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__["default"])(this, _self, name);
  }
  (0,_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(IPC_router, [{
    key: "call",
    value: function call(target, type) {
      var expect_resp = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : false;
      var _this = this;
      return _util_etask_js__WEBPACK_IMPORTED_MODULE_5___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().mark(function _callee() {
        var res;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().wrap(function _callee$(_context) {
          while (1) switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return _classPrivateMethodGet(_this, _send, _send2).call(_this, {
                target: target,
                type: type
              }, expect_resp);
            case 2:
              res = _context.sent;
              return _context.abrupt("return", res);
            case 4:
            case "end":
              return _context.stop();
          }
        }, _callee);
      }));
    }
  }, {
    key: "post",
    value: function post(target, type, data) {
      var expect_resp = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
      var _this = this;
      return _util_etask_js__WEBPACK_IMPORTED_MODULE_5___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().mark(function _callee2() {
        var res;
        return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().wrap(function _callee2$(_context2) {
          while (1) switch (_context2.prev = _context2.next) {
            case 0:
              _context2.next = 2;
              return _classPrivateMethodGet(_this, _send, _send2).call(_this, {
                target: target,
                type: type,
                data: data
              }, expect_resp);
            case 2:
              res = _context2.sent;
              return _context2.abrupt("return", res);
            case 4:
            case "end":
              return _context2.stop();
          }
        }, _callee2);
      }));
    }
  }, {
    key: "once",
    value: function once(from, type, res_fn) {
      this.on(from, type, res_fn, true);
    }
  }, {
    key: "on",
    value: function on(from, type, res_fn) {
      var once = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : false;
      var _this = this,
        ev_key = "".concat(from, "_").concat(type, "_").concat(once ? 'once' : '');
      var listener = function listener(request, sender, send_responce) {
        if (request.type != type || request.target && request.target != (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(_this, _self) || from && request.from != from) {
          return;
        }
        if (once) _this.off(ev_key);
        var key = self.crypto.randomUUID();
        send_responce({
          key: key
        });
        _util_etask_js__WEBPACK_IMPORTED_MODULE_5___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().mark(function _callee3() {
          var res;
          return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().wrap(function _callee3$(_context3) {
            while (1) switch (_context3.prev = _context3.next) {
              case 0:
                _context3.next = 2;
                return res_fn(request.data || request);
              case 2:
                res = _context3.sent;
                if (request.expect_resp) _this.post(from, key, res);
              case 4:
              case "end":
                return _context3.stop();
            }
          }, _callee3);
        }));
      };
      if ((0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _listeners).has(ev_key)) this.off(ev_key);
      (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _listeners).set(ev_key, listener);
      chrome.runtime.onMessage.addListener(listener);
    }
  }, {
    key: "off",
    value: function off(ev_key) {
      if (!(0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _listeners).has(ev_key)) return;
      chrome.runtime.onMessage.removeListener((0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _listeners).get(ev_key));
      (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _listeners)["delete"](ev_key);
    }
  }, {
    key: "clear",
    value: function clear() {
      var _this2 = this;
      (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _listeners).forEach(function (_, key) {
        return _this2.off(key);
      });
      (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _listeners).clear();
    }
  }]);
  return IPC_router;
}();
function _send2(opt, expect_resp) {
  var _this = this;
  var key,
    wait_key = _util_etask_js__WEBPACK_IMPORTED_MODULE_5___default().wait(),
    wait_responce = _util_etask_js__WEBPACK_IMPORTED_MODULE_5___default().wait();
  opt = Object.assign({}, opt, {
    from: (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _self),
    expect_resp: expect_resp
  });
  if (opt.target && opt.target == 'any') delete opt.target;
  var sending = chrome.runtime.sendMessage(opt);
  sending.then(function (resp) {
    return wait_key["continue"](resp && resp.key);
  }, function (err) {
    console.error('ERROR sending IPC', err);
    wait_key["continue"](null);
  });
  if (!expect_resp) return;
  return _util_etask_js__WEBPACK_IMPORTED_MODULE_5___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().mark(function _callee4() {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_4___default().wrap(function _callee4$(_context4) {
      while (1) switch (_context4.prev = _context4.next) {
        case 0:
          _context4.next = 2;
          return wait_key;
        case 2:
          key = _context4.sent;
          if (key) {
            _context4.next = 5;
            break;
          }
          return _context4.abrupt("return", null);
        case 5:
          _this.once(opt.target, key, function (res) {
            wait_responce["continue"](res);
          });
          return _context4.abrupt("return", wait_responce);
        case 7:
        case "end":
          return _context4.stop();
      }
    }, _callee4);
  }));
}


/***/ }),

/***/ "./src/offscreen/icon_processor.js":
/*!*****************************************!*\
  !*** ./src/offscreen/icon_processor.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Icon_processor)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/esm/createClass.js");
/* harmony import */ var _babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/classPrivateFieldGet */ "./node_modules/@babel/runtime/helpers/esm/classPrivateFieldGet.js");
/* harmony import */ var _babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/classPrivateFieldSet */ "./node_modules/@babel/runtime/helpers/esm/classPrivateFieldSet.js");
/* harmony import */ var _util_etask_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../../../../../../../util/etask.js */ "./util/etask.js");
/* harmony import */ var _util_etask_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_util_etask_js__WEBPACK_IMPORTED_MODULE_4__);
// LICENSE_CODE ZON


/*jslint browser:true, es9:true*/




function _classPrivateMethodInitSpec(obj, privateSet) { _checkPrivateRedeclaration(obj, privateSet); privateSet.add(obj); }
function _classPrivateFieldInitSpec(obj, privateMap, value) { _checkPrivateRedeclaration(obj, privateMap); privateMap.set(obj, value); }
function _checkPrivateRedeclaration(obj, privateCollection) { if (privateCollection.has(obj)) { throw new TypeError("Cannot initialize the same private elements twice on an object"); } }
function _classPrivateMethodGet(receiver, privateSet, fn) { if (!privateSet.has(receiver)) { throw new TypeError("attempted to get private field on non-instance"); } return fn; }

var _cache = /*#__PURE__*/new WeakMap();
var _busy = /*#__PURE__*/new WeakMap();
var _default_active = /*#__PURE__*/new WeakMap();
var _default_inactive = /*#__PURE__*/new WeakMap();
var _refresh = /*#__PURE__*/new WeakMap();
var _country_path = /*#__PURE__*/new WeakMap();
var _country_ext = /*#__PURE__*/new WeakMap();
var _convert_icon = /*#__PURE__*/new WeakSet();
var _get_icon = /*#__PURE__*/new WeakSet();
var Icon_processor = /*#__PURE__*/function () {
  function Icon_processor() {
    var opt = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    (0,_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, Icon_processor);
    _classPrivateMethodInitSpec(this, _get_icon);
    _classPrivateMethodInitSpec(this, _convert_icon);
    _classPrivateFieldInitSpec(this, _cache, {
      writable: true,
      value: {}
    });
    _classPrivateFieldInitSpec(this, _busy, {
      writable: true,
      value: false
    });
    _classPrivateFieldInitSpec(this, _default_active, {
      writable: true,
      value: 'img/brd_48.png'
    });
    _classPrivateFieldInitSpec(this, _default_inactive, {
      writable: true,
      value: 'img/brd_48_inactive.png'
    });
    _classPrivateFieldInitSpec(this, _refresh, {
      writable: true,
      value: 'img/brd_128_refresh.png'
    });
    _classPrivateFieldInitSpec(this, _country_path, {
      writable: true,
      value: 'flags/4x3/'
    });
    _classPrivateFieldInitSpec(this, _country_ext, {
      writable: true,
      value: 'svg'
    });
    if (opt.default_active) (0,_babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__["default"])(this, _default_active, opt.default_active);
    if (opt.default_inactive) (0,_babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__["default"])(this, _default_inactive, opt.default_inactive);
    if (opt.refresh) (0,_babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__["default"])(this, _refresh, opt.refresh);
    if (opt.country_path) (0,_babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__["default"])(this, _country_path, opt.country_path);
    if (opt.country_ext) (0,_babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__["default"])(this, _country_ext, opt.country_ext);
  }
  (0,_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(Icon_processor, [{
    key: "busy",
    get: function get() {
      return (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _busy);
    }
  }, {
    key: "get_country",
    value: function get_country(country) {
      if (self.browser) return this.get_default(true);
      var path = "".concat((0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _country_path)).concat(country, ".").concat((0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _country_ext));
      return _classPrivateMethodGet(this, _get_icon, _get_icon2).call(this, path, 32, 5);
    }
  }, {
    key: "get_default",
    value: function get_default(active) {
      var path = active ? (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _default_active) : (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _default_inactive);
      return _classPrivateMethodGet(this, _get_icon, _get_icon2).call(this, path, 48);
    }
  }, {
    key: "get_refresh",
    value: function get_refresh() {
      return _classPrivateMethodGet(this, _get_icon, _get_icon2).call(this, (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _refresh), 128);
    }
  }]);
  return Icon_processor;
}();
function _convert_icon2(src, size, on_load) {
  var _this = this;
  var off = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0;
  if ((0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _cache)[src]) return on_load((0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _cache)[src]);
  (0,_babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__["default"])(this, _busy, true);
  var canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  var ctx = canvas.getContext('2d');
  var image = new Image();
  image.onload = function () {
    ctx.drawImage(image, 0, off);
    var image_data = ctx.getImageData(0, 0, size, size);
    (0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(_this, _cache)[src] = image_data;
    (0,_babel_runtime_helpers_classPrivateFieldSet__WEBPACK_IMPORTED_MODULE_3__["default"])(_this, _busy, false);
    on_load((0,_babel_runtime_helpers_classPrivateFieldGet__WEBPACK_IMPORTED_MODULE_2__["default"])(_this, _cache)[src]);
  };
  image.src = src;
}
function _get_icon2(path, size, off) {
  var wait = _util_etask_js__WEBPACK_IMPORTED_MODULE_4___default().wait();
  _classPrivateMethodGet(this, _convert_icon, _convert_icon2).call(this, path, size, function (res) {
    return wait["continue"](res);
  }, off);
  return wait;
}


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/regeneratorRuntime.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/regeneratorRuntime.js ***!
  \*******************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var _typeof = (__webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/typeof.js")["default"]);
function _regeneratorRuntime() {
  "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */
  module.exports = _regeneratorRuntime = function _regeneratorRuntime() {
    return exports;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports;
  var exports = {},
    Op = Object.prototype,
    hasOwn = Op.hasOwnProperty,
    defineProperty = Object.defineProperty || function (obj, key, desc) {
      obj[key] = desc.value;
    },
    $Symbol = "function" == typeof Symbol ? Symbol : {},
    iteratorSymbol = $Symbol.iterator || "@@iterator",
    asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator",
    toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
  function define(obj, key, value) {
    return Object.defineProperty(obj, key, {
      value: value,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }), obj[key];
  }
  try {
    define({}, "");
  } catch (err) {
    define = function define(obj, key, value) {
      return obj[key] = value;
    };
  }
  function wrap(innerFn, outerFn, self, tryLocsList) {
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator,
      generator = Object.create(protoGenerator.prototype),
      context = new Context(tryLocsList || []);
    return defineProperty(generator, "_invoke", {
      value: makeInvokeMethod(innerFn, self, context)
    }), generator;
  }
  function tryCatch(fn, obj, arg) {
    try {
      return {
        type: "normal",
        arg: fn.call(obj, arg)
      };
    } catch (err) {
      return {
        type: "throw",
        arg: err
      };
    }
  }
  exports.wrap = wrap;
  var ContinueSentinel = {};
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}
  var IteratorPrototype = {};
  define(IteratorPrototype, iteratorSymbol, function () {
    return this;
  });
  var getProto = Object.getPrototypeOf,
    NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
  var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function (method) {
      define(prototype, method, function (arg) {
        return this._invoke(method, arg);
      });
    });
  }
  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if ("throw" !== record.type) {
        var result = record.arg,
          value = result.value;
        return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) {
          invoke("next", value, resolve, reject);
        }, function (err) {
          invoke("throw", err, resolve, reject);
        }) : PromiseImpl.resolve(value).then(function (unwrapped) {
          result.value = unwrapped, resolve(result);
        }, function (error) {
          return invoke("throw", error, resolve, reject);
        });
      }
      reject(record.arg);
    }
    var previousPromise;
    defineProperty(this, "_invoke", {
      value: function value(method, arg) {
        function callInvokeWithMethodAndArg() {
          return new PromiseImpl(function (resolve, reject) {
            invoke(method, arg, resolve, reject);
          });
        }
        return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
      }
    });
  }
  function makeInvokeMethod(innerFn, self, context) {
    var state = "suspendedStart";
    return function (method, arg) {
      if ("executing" === state) throw new Error("Generator is already running");
      if ("completed" === state) {
        if ("throw" === method) throw arg;
        return doneResult();
      }
      for (context.method = method, context.arg = arg;;) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }
        if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) {
          if ("suspendedStart" === state) throw state = "completed", context.arg;
          context.dispatchException(context.arg);
        } else "return" === context.method && context.abrupt("return", context.arg);
        state = "executing";
        var record = tryCatch(innerFn, self, context);
        if ("normal" === record.type) {
          if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
          return {
            value: record.arg,
            done: context.done
          };
        }
        "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
      }
    };
  }
  function maybeInvokeDelegate(delegate, context) {
    var methodName = context.method,
      method = delegate.iterator[methodName];
    if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
    var record = tryCatch(method, delegate.iterator, context.arg);
    if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
    var info = record.arg;
    return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
  }
  function pushTryEntry(locs) {
    var entry = {
      tryLoc: locs[0]
    };
    1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
  }
  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal", delete record.arg, entry.completion = record;
  }
  function Context(tryLocsList) {
    this.tryEntries = [{
      tryLoc: "root"
    }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
  }
  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) return iteratorMethod.call(iterable);
      if ("function" == typeof iterable.next) return iterable;
      if (!isNaN(iterable.length)) {
        var i = -1,
          next = function next() {
            for (; ++i < iterable.length;) if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
            return next.value = undefined, next.done = !0, next;
          };
        return next.next = next;
      }
    }
    return {
      next: doneResult
    };
  }
  function doneResult() {
    return {
      value: undefined,
      done: !0
    };
  }
  return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
    value: GeneratorFunctionPrototype,
    configurable: !0
  }), defineProperty(GeneratorFunctionPrototype, "constructor", {
    value: GeneratorFunction,
    configurable: !0
  }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) {
    var ctor = "function" == typeof genFun && genFun.constructor;
    return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
  }, exports.mark = function (genFun) {
    return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
  }, exports.awrap = function (arg) {
    return {
      __await: arg
    };
  }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () {
    return this;
  }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    void 0 === PromiseImpl && (PromiseImpl = Promise);
    var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
    return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) {
      return result.done ? result.value : iter.next();
    });
  }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () {
    return this;
  }), define(Gp, "toString", function () {
    return "[object Generator]";
  }), exports.keys = function (val) {
    var object = Object(val),
      keys = [];
    for (var key in object) keys.push(key);
    return keys.reverse(), function next() {
      for (; keys.length;) {
        var key = keys.pop();
        if (key in object) return next.value = key, next.done = !1, next;
      }
      return next.done = !0, next;
    };
  }, exports.values = values, Context.prototype = {
    constructor: Context,
    reset: function reset(skipTempReset) {
      if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
    },
    stop: function stop() {
      this.done = !0;
      var rootRecord = this.tryEntries[0].completion;
      if ("throw" === rootRecord.type) throw rootRecord.arg;
      return this.rval;
    },
    dispatchException: function dispatchException(exception) {
      if (this.done) throw exception;
      var context = this;
      function handle(loc, caught) {
        return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
      }
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i],
          record = entry.completion;
        if ("root" === entry.tryLoc) return handle("end");
        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc"),
            hasFinally = hasOwn.call(entry, "finallyLoc");
          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
            if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
          } else {
            if (!hasFinally) throw new Error("try statement without catch or finally");
            if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
          }
        }
      }
    },
    abrupt: function abrupt(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }
      finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
      var record = finallyEntry ? finallyEntry.completion : {};
      return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
    },
    complete: function complete(record, afterLoc) {
      if ("throw" === record.type) throw record.arg;
      return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
    },
    finish: function finish(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
      }
    },
    "catch": function _catch(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if ("throw" === record.type) {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }
      throw new Error("illegal catch attempt");
    },
    delegateYield: function delegateYield(iterable, resultName, nextLoc) {
      return this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
    }
  }, exports;
}
module.exports = _regeneratorRuntime, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/typeof.js":
/*!*******************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/typeof.js ***!
  \*******************************************************/
/***/ ((module) => {

function _typeof(obj) {
  "@babel/helpers - typeof";

  return (module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) {
    return typeof obj;
  } : function (obj) {
    return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
  }, module.exports.__esModule = true, module.exports["default"] = module.exports), _typeof(obj);
}
module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;

/***/ }),

/***/ "./node_modules/@babel/runtime/regenerator/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@babel/runtime/regenerator/index.js ***!
  \**********************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

// TODO(Babel 8): Remove this file.

var runtime = __webpack_require__(/*! ../helpers/regeneratorRuntime */ "./node_modules/@babel/runtime/helpers/regeneratorRuntime.js")();
module.exports = runtime;

// Copied from https://github.com/facebook/regenerator/blob/main/packages/runtime/runtime.js#L736=
try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  if (typeof globalThis === "object") {
    globalThis.regeneratorRuntime = runtime;
  } else {
    Function("r", "regeneratorRuntime = r")(runtime);
  }
}


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/classApplyDescriptorGet.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/classApplyDescriptorGet.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _classApplyDescriptorGet)
/* harmony export */ });
function _classApplyDescriptorGet(receiver, descriptor) {
  if (descriptor.get) {
    return descriptor.get.call(receiver);
  }
  return descriptor.value;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/classApplyDescriptorSet.js":
/*!****************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/classApplyDescriptorSet.js ***!
  \****************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _classApplyDescriptorSet)
/* harmony export */ });
function _classApplyDescriptorSet(receiver, descriptor, value) {
  if (descriptor.set) {
    descriptor.set.call(receiver, value);
  } else {
    if (!descriptor.writable) {
      throw new TypeError("attempted to set read only private field");
    }
    descriptor.value = value;
  }
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/classCallCheck.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/classCallCheck.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _classCallCheck)
/* harmony export */ });
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/classExtractFieldDescriptor.js":
/*!********************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/classExtractFieldDescriptor.js ***!
  \********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _classExtractFieldDescriptor)
/* harmony export */ });
function _classExtractFieldDescriptor(receiver, privateMap, action) {
  if (!privateMap.has(receiver)) {
    throw new TypeError("attempted to " + action + " private field on non-instance");
  }
  return privateMap.get(receiver);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/classPrivateFieldGet.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/classPrivateFieldGet.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _classPrivateFieldGet)
/* harmony export */ });
/* harmony import */ var _classApplyDescriptorGet_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./classApplyDescriptorGet.js */ "./node_modules/@babel/runtime/helpers/esm/classApplyDescriptorGet.js");
/* harmony import */ var _classExtractFieldDescriptor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./classExtractFieldDescriptor.js */ "./node_modules/@babel/runtime/helpers/esm/classExtractFieldDescriptor.js");


function _classPrivateFieldGet(receiver, privateMap) {
  var descriptor = (0,_classExtractFieldDescriptor_js__WEBPACK_IMPORTED_MODULE_1__["default"])(receiver, privateMap, "get");
  return (0,_classApplyDescriptorGet_js__WEBPACK_IMPORTED_MODULE_0__["default"])(receiver, descriptor);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/classPrivateFieldSet.js":
/*!*************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/classPrivateFieldSet.js ***!
  \*************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _classPrivateFieldSet)
/* harmony export */ });
/* harmony import */ var _classApplyDescriptorSet_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./classApplyDescriptorSet.js */ "./node_modules/@babel/runtime/helpers/esm/classApplyDescriptorSet.js");
/* harmony import */ var _classExtractFieldDescriptor_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./classExtractFieldDescriptor.js */ "./node_modules/@babel/runtime/helpers/esm/classExtractFieldDescriptor.js");


function _classPrivateFieldSet(receiver, privateMap, value) {
  var descriptor = (0,_classExtractFieldDescriptor_js__WEBPACK_IMPORTED_MODULE_1__["default"])(receiver, privateMap, "set");
  (0,_classApplyDescriptorSet_js__WEBPACK_IMPORTED_MODULE_0__["default"])(receiver, descriptor, value);
  return value;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/createClass.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/createClass.js ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _createClass)
/* harmony export */ });
/* harmony import */ var _toPropertyKey_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./toPropertyKey.js */ "./node_modules/@babel/runtime/helpers/esm/toPropertyKey.js");

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, (0,_toPropertyKey_js__WEBPACK_IMPORTED_MODULE_0__["default"])(descriptor.key), descriptor);
  }
}
function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  Object.defineProperty(Constructor, "prototype", {
    writable: false
  });
  return Constructor;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/defineProperty.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _defineProperty)
/* harmony export */ });
/* harmony import */ var _toPropertyKey_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./toPropertyKey.js */ "./node_modules/@babel/runtime/helpers/esm/toPropertyKey.js");

function _defineProperty(obj, key, value) {
  key = (0,_toPropertyKey_js__WEBPACK_IMPORTED_MODULE_0__["default"])(key);
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }
  return obj;
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/toPrimitive.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/toPrimitive.js ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _toPrimitive)
/* harmony export */ });
/* harmony import */ var _typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");

function _toPrimitive(input, hint) {
  if ((0,_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(input) !== "object" || input === null) return input;
  var prim = input[Symbol.toPrimitive];
  if (prim !== undefined) {
    var res = prim.call(input, hint || "default");
    if ((0,_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(res) !== "object") return res;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (hint === "string" ? String : Number)(input);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/toPropertyKey.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/toPropertyKey.js ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _toPropertyKey)
/* harmony export */ });
/* harmony import */ var _typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./typeof.js */ "./node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var _toPrimitive_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./toPrimitive.js */ "./node_modules/@babel/runtime/helpers/esm/toPrimitive.js");


function _toPropertyKey(arg) {
  var key = (0,_toPrimitive_js__WEBPACK_IMPORTED_MODULE_1__["default"])(arg, "string");
  return (0,_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(key) === "symbol" ? key : String(key);
}

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/esm/typeof.js":
/*!***********************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/esm/typeof.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _typeof)
/* harmony export */ });
function _typeof(obj) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) {
    return typeof obj;
  } : function (obj) {
    return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
  }, _typeof(obj);
}

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!********************************!*\
  !*** ./src/offscreen/index.js ***!
  \********************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _util_etask_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../../../util/etask.js */ "./util/etask.js");
/* harmony import */ var _util_etask_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_util_etask_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _util_ipc_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util/ipc.js */ "./src/util/ipc.js");
/* harmony import */ var _icon_processor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./icon_processor.js */ "./src/offscreen/icon_processor.js");
/* harmony import */ var _util_consts_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../util/consts.js */ "./src/util/consts.js");
// LICENSE_CODE ZON


/*jslint browser:true, es6:true*/






var keys = Object.keys,
  assign = Object.assign;
var MESSAGES = _util_consts_js__WEBPACK_IMPORTED_MODULE_5__.IPC.MESSAGES,
  IDS = _util_consts_js__WEBPACK_IMPORTED_MODULE_5__.IPC.IDS,
  HEARTBEAT_INTERVAL = _util_consts_js__WEBPACK_IMPORTED_MODULE_5__.IPC.HEARTBEAT_INTERVAL;
var HEARTBEAT = MESSAGES.HEARTBEAT,
  ECHO = MESSAGES.ECHO,
  READY = MESSAGES.READY,
  ICON = MESSAGES.ICON;
var handlers = (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, ECHO, function (msg) {
  return msg.data.result;
});
var wait = {
  set: function set(key) {
    if (wait[key]) wait["continue"](key);
    return wait[key] = _util_etask_js__WEBPACK_IMPORTED_MODULE_2___default().wait();
  },
  "continue": function _continue(key) {
    var data = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    if (!wait[key]) return;
    wait[key]["continue"](data);
    delete wait[key];
  }
};
var echo_worker,
  router,
  icon_processor = new _icon_processor_js__WEBPACK_IMPORTED_MODULE_4__["default"]();
var is_valid = function is_valid(_ref) {
  var data = _ref.data;
  return is_valid_type(data.type) && is_valid_key(data.key);
};
var is_valid_type = function is_valid_type(type) {
  return keys(handlers).includes(type);
};
var is_valid_key = function is_valid_key(key) {
  return !!wait[key];
};
var worker_message_handler = function worker_message_handler(msg) {
  if (msg.data == HEARTBEAT) return msg.currentTarget.handle_heartbeat();
  if (!msg.data || !is_valid(msg)) return;
  _util_etask_js__WEBPACK_IMPORTED_MODULE_2___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee() {
    var res;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee$(_context) {
      while (1) switch (_context.prev = _context.next) {
        case 0:
          _context.next = 2;
          return handlers[msg.data.type](msg);
        case 2:
          res = _context.sent;
          wait["continue"](msg.data.key, res);
        case 4:
        case "end":
          return _context.stop();
      }
    }, _callee);
  }));
};
var worker_error_handler = function worker_error_handler(err) {
  return console.error('ECHO WORKER ERROR', err);
};
function worker_close() {
  keys(wait).forEach(function (k) {
    return wait["continue"](k);
  });
  this._selfClose();
}
var handle_heartbeat = function handle_heartbeat() {
  echo_worker[HEARTBEAT] = Date.now();
  wait["continue"](HEARTBEAT);
};
var worker_alive = function worker_alive() {
  return echo_worker[HEARTBEAT] && Date.now() - echo_worker[HEARTBEAT] < 3 * HEARTBEAT_INTERVAL;
};
var setup_worker = function setup_worker(worker) {
  worker.onmessage = worker_message_handler;
  worker.onerror = worker_error_handler;
  worker._selfClose = worker_close;
  worker.alive = worker_alive;
  worker.handle_heartbeat = handle_heartbeat;
};
var restart_worker = function restart_worker(callback) {
  return _util_etask_js__WEBPACK_IMPORTED_MODULE_2___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee2() {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee2$(_context2) {
      while (1) switch (_context2.prev = _context2.next) {
        case 0:
          if (!wait[HEARTBEAT]) {
            _context2.next = 2;
            break;
          }
          return _context2.abrupt("return");
        case 2:
          wait.set(HEARTBEAT);
          if (echo_worker) echo_worker.terminate();
          echo_worker = new Worker('echo_worker.js', {
            name: 'echo_worker'
          });
          setup_worker(echo_worker);
          _context2.next = 8;
          return wait[HEARTBEAT];
        case 8:
          if (callback) callback();
          if (router) router.call(IDS.ANY, READY);
        case 10:
        case "end":
          return _context2.stop();
      }
    }, _callee2);
  }));
};
var post_message = function post_message(type) {
  var opt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (!is_valid_type(type)) throw 'OFFSCREEN: Invalid message type';
  if (!echo_worker || !echo_worker.alive()) {
    setTimeout(restart_worker);
    return null;
  }
  return call_worker(type, opt = {});
};
var call_worker = function call_worker(type) {
  var opt = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var key = self.crypto.randomUUID();
  echo_worker.postMessage(assign({}, opt, {
    type: type,
    key: key
  }));
  return wait.set(key);
};
var heartbeat = function heartbeat() {
  return router.call(IDS.BG, HEARTBEAT);
};
var init_router = function init_router() {
  router = new _util_ipc_js__WEBPACK_IMPORTED_MODULE_3__["default"]('offscreen');
  router.on(IDS.BG, ECHO, function () {
    return _util_etask_js__WEBPACK_IMPORTED_MODULE_2___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee3() {
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            _context3.next = 2;
            return post_message(ECHO);
          case 2:
            return _context3.abrupt("return", _context3.sent);
          case 3:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }));
  });
  router.on(IDS.BG, ICON, function (data) {
    return _util_etask_js__WEBPACK_IMPORTED_MODULE_2___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().mark(function _callee4() {
      var image_data, switching, enabled, country;
      return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default().wrap(function _callee4$(_context4) {
        while (1) switch (_context4.prev = _context4.next) {
          case 0:
            if (!icon_processor.busy) {
              _context4.next = 2;
              break;
            }
            return _context4.abrupt("return", {
              busy: true
            });
          case 2:
            switching = data.switching, enabled = data.enabled, country = data.country;
            if (!switching) {
              _context4.next = 9;
              break;
            }
            _context4.next = 6;
            return icon_processor.get_refresh();
          case 6:
            image_data = _context4.sent;
            _context4.next = 18;
            break;
          case 9:
            if (!(!enabled || !country)) {
              _context4.next = 15;
              break;
            }
            _context4.next = 12;
            return icon_processor.get_default(enabled);
          case 12:
            image_data = _context4.sent;
            _context4.next = 18;
            break;
          case 15:
            _context4.next = 17;
            return icon_processor.get_country(country);
          case 17:
            image_data = _context4.sent;
          case 18:
            return _context4.abrupt("return", {
              data: Array.from(image_data.data),
              width: image_data.width,
              height: image_data.height,
              colorSpace: image_data.colorSpace
            });
          case 19:
          case "end":
            return _context4.stop();
        }
      }, _callee4);
    }));
  });
  heartbeat();
  setInterval(heartbeat, 20 * HEARTBEAT_INTERVAL);
};
restart_worker(init_router);
})();

/******/ })()
;