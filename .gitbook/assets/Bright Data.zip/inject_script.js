/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};
/*!**************************************!*\
  !*** ./src/content/inject_script.js ***!
  \**************************************/
// LICENSE_CODE ZON


/*jslint browser:true, es6:true, react:true*/
(function (opt) {
  window.bext_running = true;
  window.bext_url = opt.bext_url;
})(document.currentScript.dataset);
/******/ })()
;